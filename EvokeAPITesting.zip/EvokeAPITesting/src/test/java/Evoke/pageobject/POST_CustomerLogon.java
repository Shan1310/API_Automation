//Auther : shantanu devkar
package Evoke.pageobject;

import java.util.LinkedHashMap;
import org.json.simple.JSONObject;

import Evoke.testdataobjects.LogonDataObject;
import Evoke.utilities.JsonDataReader;
import Evoke.utilities.TestBase;
import gherkin.deps.com.google.gson.internal.LinkedTreeMap;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class POST_CustomerLogon extends TestBase {
	public static String cook;

	public static String loggedinresponse;

	public static String loggdinstatus;

	public static String loggedinstat;

	public static int statuscode;

	static LinkedTreeMap<String, ?> logondataobject =JsonDataReader.getMapfromJson("TestData/Login.json","Login");
	 static LogonDataObject login = new LogonDataObject(logondataobject);
	public static void logon()

	{
				
		
		try {
			CommonRequest com = new CommonRequest();
			RequestSpecification request = com.getSpecificationRequest();
					
			JSONObject json = new JSONObject();

			json.put("email", Emailidvalue);
			json.put("password", Passwordvalue);

			request.body(json.toJSONString());

			Response rep = request.given().log().all().post("/customer/logon");

			System.out.println("Request is" + rep);

			String loggedinresponse = rep.getBody().asString();
			
			System.out.println("Testing Logon"+loggedinresponse);
			statuscode = rep.getStatusCode();
			loggedinstat = rep.path("logon.logonmessage").toString();

			cook = rep.getDetailedCookies().toString();

			Allure.addAttachment("Logon call run",
					"Logon call ran successfully and response is as below \n " + loggedinresponse);
		} catch (Exception e) {
			Allure.addAttachment("Logon call run", "Logon call was not successful");

		}
	}

	public static void login_credentials() {

	}

	public static void getloggedinstatus() {
		try {
			String Exptectedlogonstatus = "GeneralUserLoggedOn";

			String loggdinstatus = POST_CustomerLogon.loggedinstat;

			if (Exptectedlogonstatus.equalsIgnoreCase(Exptectedlogonstatus))

			{
				Allure.addAttachment("User loggedIn status is", "GeneralUserLoggedOn" + loggdinstatus);
			}

		} catch (Exception e) {
			Allure.addAttachment("User loggedIn status is", "Logon was not successful hence no logon message");

		}

	}

	public static void getlogonstatuscode() {

		int Expectedstatuscode = 200;

		int Actualstatuscode = POST_CustomerLogon.statuscode;

		try {

			if (Expectedstatuscode == Actualstatuscode) {
				Allure.attachment("Status code of the Logon",
						"Status code of the Logon API is => " + Expectedstatuscode);
			}
		}

		catch (Exception e) {
			Allure.attachment("Logon status code is not as expected",
					"Current status code for Logon API is =>" + Actualstatuscode);

		}

	}

	/***************
	 * * This is a method to logon with new password
	 ***********************************/

	public static void logonwithnewpassword()

	{
		try {
			CommonRequest com = new CommonRequest();
			RequestSpecification request = com.getSpecificationRequest();
			request.given().auth().preemptive().basic(prop.getProperty("Username"), prop.getProperty("Password"));

			JSONObject json = new JSONObject();

			// System.out.println("New passwod is coming as => " +
			// login.getNewPasswordValue());

			json.put(login.getUserNameField(), login.getUsernameValue());
			 json.put(login.getPasswordField(), login.getNewPasswordValue());
			 json.put(login.getStaffidField(), login.getStaffIdValue());

			request.body(json.toJSONString());

			Response rep = request.post("/customer/logon");
			String loggedinresponse = rep.getBody().asString();
			statuscode = rep.getStatusCode();
			System.out.println("User Logon status is as below => \n " + loggedinresponse);

			loggedinstat = rep.path("logon.logonmessage").toString();

			cook = rep.getDetailedCookies().toString();

			Allure.addAttachment("Logon call run After changed of passwrod",
					"Logon after changed password ran successfully with below response \n" + loggedinresponse);
		} catch (Exception e) {
			Allure.addAttachment("Logon call run", "Logon call was not successful");

		}
	}

	public static void loginnewcredentials() {

		// RequestSpecification request = RestAssured.given();

		// request.given().auth().preemptive().basic("test1", "test");

	}

	public static void getloggedinuserstatus() {
		try {
			String Exptectedlogonstatus = "GeneralUserLoggedOn";

			String loggdinstatus = POST_CustomerLogon.loggedinstat;

			if (Exptectedlogonstatus.equalsIgnoreCase(Exptectedlogonstatus))

			{
				Allure.addAttachment("User loggedIn status is", "GeneralUserLoggedOn");
			}

		} catch (Exception e) {
			Allure.addAttachment("User loggedIn status is", "Logon was not successful hence no logon message");

		}

	}

	public static void getlogonuserstatuscode() {
		int Expectedstatuscode = 200;

		int Actualstatuscode = POST_CustomerLogon.statuscode;

		try {

			if (Expectedstatuscode == Actualstatuscode) {
				Allure.attachment("Status code of the Logon",
						"Status code of the Logon API is => " + Expectedstatuscode);
			}
		}

		catch (Exception e) {
			Allure.attachment("Logon status code is not as expected",
					"Current status code for Logon API is =>" + Actualstatuscode);

		}
	}

}
