//Auther : shantanu devkar
package Evoke.pageobject;


import java.util.LinkedHashMap;

import org.apache.http.client.ClientProtocolException;
import org.json.simple.JSONObject;
import org.testng.asserts.SoftAssert;

import Evoke.utilities.TestBase;
import groovyjarjarasm.asm.Type;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;


public class POST_EndShift extends TestBase {
	public static String Tisid;
	public static String cook;
	public static String EndshiftResponse;
	public static int EndshiftResponseStatuscode;
	public static RequestSpecification req;
	public static void endshift(LinkedHashMap<String, String> linkedHashMap)throws ClientProtocolException{
		 
		try
		{
			
	  System.out.println(linkedHashMap); 
	  RestAssured.baseURI =prop.getProperty("EvokeBaseURL"); 
	  RequestSpecification request = RestAssured.given(); 

	  String tisid = linkedHashMap.get("tisid");
	  Response response = request.given()
	  .header("TisId",tisid).
	   header("content-Type", linkedHashMap.get("Content-Type"))
	   .with()
	  .auth().preemptive().basic(prop.getProperty("Username"),
	  prop.getProperty("Password")).
	  when().given().log().all().post("/shift/end");
	  
	  ResponseBody respbody = response.getBody(); 
	  EndshiftResponse = respbody.asString(); 
	  cook = response.getDetailedCookies().toString();
	  request.cookie(cook);
	  
	  System.out.println("Rail resp cookie" + cook);
	  System.out.println("End Shift response is :" +EndshiftResponse);
	  
	  EndshiftResponseStatuscode = response.getStatusCode();
	  
	  softassert7.assertEquals(response.getStatusCode(), 200);
	  System.out.println("End shift started successfully and the status is 200 as Expected: "+EndshiftResponseStatuscode);
					
	  Allure.attachment("End Shift Response", "End Shift run successfully and response is as below: \n" +EndshiftResponse);
	  Allure.attachment("Response Status", "Response Status as : \n" +EndshiftResponseStatuscode);
		
		}
			catch(Exception e)
		{
			e.printStackTrace();
			Allure.attachment("End Shift Response", "End Shift couldn't run successfully and Error is as shown below: \n" +EndshiftResponse );
		}

	}
	
}
