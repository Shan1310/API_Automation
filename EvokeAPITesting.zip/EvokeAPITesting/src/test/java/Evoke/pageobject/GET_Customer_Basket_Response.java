//Auther : shantanu devkar
package Evoke.pageobject;

import java.util.LinkedHashMap;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Evoke.utilities.TestBase;
import io.qameta.allure.Allure;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GET_Customer_Basket_Response extends TestBase {
	public static RequestSpecification request;
	public static String sbasket;
    public static String totalAmount=null; 
    public static int GetBasketResponseStatuscode;

	public static void getbasket() throws Exception{
	 
		try {
		CommonRequest common = new CommonRequest();
		request = common.getSpecificationRequest();

		Response resp = request.given().cookie(POST_StartShift.cook).auth().preemptive()
				.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().log().all()
				.get("/customer/basket");
		GetBasketResponseStatuscode = resp.getStatusCode();
 	    
		softassert4.assertEquals(resp.getStatusCode(), 200);
		
		sbasket = resp.getBody().asString();
		Allure.attachment("Get Basket Response Status code ", "Get Customer Basket run successfully and status is as shown below: \n" +GetBasketResponseStatuscode );
		Allure.addAttachment("Your basket content is as below => "+POST_JourneySearch.FromLocation+ " To "+POST_JourneySearch.ToLocation, sbasket);
		System.out.println("Your Basket Response is : " + sbasket);
		totalAmount = resp.path("getbasketresponse.totalcostpence").toString();

		System.out.println("basketcost is: " + totalAmount);
		}
		
		catch(Exception e)
	{
		Allure.attachment("Get Basket Response Status code", "Get Customer Basket couldn't run successfully and Error is as shown below: \n" +GetBasketResponseStatuscode );
	}	

	
}
		
	}


