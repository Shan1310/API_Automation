//Auther : shantanu devkar
package Evoke.pageobject;


import java.util.LinkedHashMap;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Evoke.utilities.TestBase;
import io.qameta.allure.Allure;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;


public class POST_CustomerBasket extends TestBase {
	public static String CustomerbasketResponse;

	public static void sendcustomerbasket(LinkedHashMap<String, String> linkedHashMap)
	{
		SoftAssert check2 = new SoftAssert(); 
		
		try
		{
			
			System.out.println("Oneway "+POST_JourneySearch.Oneway);
			System.out.println("Openreturn "+POST_JourneySearch.Openreturn);
			
			String oneway = POST_JourneySearch.Oneway;
			String openreturn = POST_JourneySearch.Openreturn;
			String isReturnflag = linkedHashMap.get("isReturnFlag");
			String isOpenReturn = linkedHashMap.get("openreturn");
			
			
			
			  if(oneway.equals("0") && isReturnflag.equals("0")) {
			  
			  System.out.println("faregroup is coming as "+POST_JourneySearch.outwardfaregroup); 
			  CommonRequest com = new CommonRequest();
			  RequestSpecification request = com.getSpecificationRequest();
			  System.out.println("Cookie is"+POST_StartShift.cook);
			  request.cookie(POST_StartShift.cook);
			  request.header("outwardFareGroup ",POST_JourneySearch.outwardfaregroup);
			  
			  System.out.println("faregroup is coming as "+POST_JourneySearch. outwardfaregroup);
			  
			  request.header("outwardserviceid ",POST_JourneySearch.outwardserviceid);
			  
			  System.out.println("service id is coming as "+POST_JourneySearch. outwardserviceid);
			  
			  request.header("returnServiceid ",POST_JourneySearch.ReturnServiceid);
			  
			  System.out.println("Return Service ID is coming as "+POST_JourneySearch.ReturnServiceid);
			  
			  request.header("returnFareGroup ",POST_JourneySearch.Returnfaregroup);
			  
			  System.out.println("Return Fare Group is coming as "+POST_JourneySearch.Returnfaregroup);
			  request.given().auth().preemptive(). basic(prop.getProperty("Username"),prop.getProperty("Password"));
			  Response response = request.given().log().all().post("/customer/basket");
			  ResponseBody respbody = response.getBody(); 
			  CustomerbasketResponse = respbody.asString();
			  System.out.println("Add to Basket response is :"+CustomerbasketResponse);
			  //int Customerbasketstatuscode = response.getStatusCode(); 
			  check2.assertEquals(response.getStatusCode(), 201);
			  }
			 
			  else if  (oneway.equals("0") && isReturnflag.equals("1")) {
				System.out.println("faregroup is coming as "+POST_JourneySearch.outwardfaregroup);
				CommonRequest com = new CommonRequest();
				RequestSpecification request = com.getSpecificationRequest();
				System.out.println("Cookie is"+POST_StartShift.cook);
				request.cookie(POST_StartShift.cook);
				request.header("outwardFareGroup ",POST_JourneySearch.outwardfaregroup);
				
				System.out.println("faregroup is coming as "+POST_JourneySearch.outwardfaregroup);
				
				request.header("outwardserviceid ",POST_JourneySearch.outwardserviceid);
				
				System.out.println("service id is coming as "+POST_JourneySearch.outwardserviceid);	
				
				request.given().auth().preemptive().basic(prop.getProperty("Username"),prop.getProperty("Password"));
				
				Response response = request.given().log().all().post("/customer/basket");
				
				ResponseBody respbody = response.getBody();
				CustomerbasketResponse = respbody.asString();
				System.out.println("Basket response is "+CustomerbasketResponse);
				
				int Customerbasketstatuscode = response.getStatusCode();
				check2.assertEquals(response.getStatusCode(), 201);
			}
			else
			{
				System.out.println("faregroup is coming as "+POST_JourneySearch.outwardfaregroup);
				CommonRequest com = new CommonRequest();
				RequestSpecification request = com.getSpecificationRequest();
				System.out.println("Cookie is"+POST_StartShift.cook);
				request.cookie(POST_StartShift.cook);
				request.header("outwardFareGroup ",POST_JourneySearch.outwardfaregroup);
				
				System.out.println("faregroup is coming as "+POST_JourneySearch.outwardfaregroup);
				
				request.header("outwardserviceid ",POST_JourneySearch.outwardserviceid);
				
				System.out.println("service id is coming as "+POST_JourneySearch.outwardserviceid);	
				
				request.given().auth().preemptive().basic(prop.getProperty("Username"),prop.getProperty("Password"));
				
				Response response = request.given().log().all().post("/customer/basket");
				
				ResponseBody respbody = response.getBody();
				CustomerbasketResponse = respbody.asString();
				System.out.println("Basket response is "+CustomerbasketResponse);
				
				//int Customerbasketstatuscode = response.getStatusCode();
				check2.assertEquals(response.getStatusCode(), 201);
			}
		Allure.attachment("Customer Basket Response", "Customer basket ran successfully and response is as below: \n" +CustomerbasketResponse);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Allure.attachment("Customer Basket Responser", "Customer basket couldn't run successfully is as below: \n" +CustomerbasketResponse);
		}
//		check2.assertAll();
	}
	private static void If(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
