//Auther : shantanu devkar
package Evoke.pageobject;

import java.net.URL;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.SendKeysAction;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import Evoke.utilities.Screenshot;
import Evoke.utilities.TestBase;
import bsh.Capabilities;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ResponseOptions;
import io.restassured.specification.RequestSpecification;
import jdk.internal.org.jline.utils.Log;

public class GET_Configuration extends TestBase {
	public static RequestSpecification request;
	public static String cook;
	public static String ConfigurationResponse;
	public static int GetConfigurationResponseStatuscode;
	public static WebDriver driver;
	static TestBase testBase = new TestBase();

	public static By loginID = By.id("LogonId");
	public static By loginPassword = By.id("LoginPasscode");
	public static By loginButton = By.xpath("//button[@title='Login']");

	public static By AdminData = By.xpath("//a[@href='/WorldlineDevConsole/AdminData']");
	public static By AdminDataPageLayout = By.xpath("//div[@class='panel panel-primary']");
	public static By ClickOnApplicationDropdown = By.xpath("//select[@id='ddlAdminDataList']");
	public static By SelectOrganisation = By.xpath("//option[text()='Organisations']");
	public static By ClickonSearchField = By.xpath("//div[@class='pull-right search']");
	public static By EditOrgRow = By.xpath("//div[@class='form-group row']");

	public static By ShortName = By.xpath("//input[@id='ShortName']");
	public static By LongName = By.xpath("//input[@id='LongName']");
	public static By VAT_No = By.xpath("//input[@id='VAT']");
	public static By Save_Btn = By.xpath("//button[@id='btnSave']");

	public static By AppConfig = By.xpath("//a[@href='/WorldlineDevConsole/Configurations']");
	public static By AppConfigLayout = By.xpath("//div[@class='panel panel-primary']");
	public static By ClickOnfavourites = By.xpath("//span[@id='favourites']");
	public static By SelectPopularDiscountCodes = By.xpath("//a[@href='#DivPopularDiscountCodes']");
	public static By DevDefaultDetails = By.xpath("//td[text()='Development Default']");

	public static By appConfigButton = By.xpath("//span[contains(text(),'App Config')]/parent::a");
	public static By AppConfigurePage = By.xpath("//div[@class='wrapper']");

	public static By Favourites = By.xpath("//a[@id='TabDrop']");
	public static By SelectPopularRailcardoption = By.xpath("//a[@id='DivPopularDiscountCodes-tab']");
	public static By SelectOrg = By.xpath("//select[@id='OrganisationDiscountCodesFilter']");
	public static By edit = By.xpath("//button[@class='btn btnEdit']");
	public static By edit1 = By.xpath("//*[@id='tablePopularDiscountCodesLists']//*[@class='btn btnEdit']");
	public static By editRoute = By.xpath("//*[@id='tableExcludeRoutesLists']//*[@class='btn btnEdit']");
	public static By Header = By.xpath("//h1[contains(text(), 'Edit Popular Discount Codes List')]");
	public static By HeaderforExcludeRoute = By.xpath("//h1[contains(text(), 'Edit Routes List')]");

	public static By AddpopularRailcard = By.xpath("//*[@id='UnSelectedItems_SelectedRailcardsIds']//*[@value='3']");
	public static By MoveSelectedRailcard = By.xpath("//button[@id='MoveSelected_SelectedRailcardsIds']");
	public static By Save = By.xpath("//*[@class='btn btn-SaveOk']");

	public static By Save_Button = By.xpath("//input[@class='btn btn-SaveOk']");
	public static By ExcludeList_Tab = By.xpath("//a[@id='TabExclude']");
	public static By ExcludeRoutes_option = By.xpath("//a[@id='DivExcludeRoutes-tab']");
	public static By pagination = By.xpath("//span[text()='Showing 1 to 1 of 1 rows']");
	public static By OrgDropdown = By.xpath("//select[@id='OrganisationDiscountCodesFilter']");
	public static By ExcludeList_OrgDropdown = By.xpath("//select[@id='OrganisationERTListFilter']");

	public static By AddRoutes = By.xpath("//select[@name='SelectItemRoutesEdit_helper1']//*[@value='15']");
	public static By MoveSelectedRoutes = By.xpath("//button[@class='btn move btn-WorldLineBlue']");

	public static By ExcludeTicketType = By.xpath("//a[@id='TicketTypes-tab']");
	public static By ExcludedTicketType_OrgDropdown = By.xpath("//select[@id='OrganisationETTListFilter']");
	public static By Edit_ExcludedTicketType = By.xpath("//*[@id='tableExcludeTicketTypesLists']//*[@class='btn btnEdit']");
	public static By HeaderforExcludeTicketType = By.xpath("//h1[contains(text(), 'Edit Exclude Ticket Type List')]");
	public static By AddTicketType = By.xpath("//*[@id='bootstrap-duallistbox-nonselected-list_SelectItemTicketTypes']//*[@value='5547']");
	public static By MoveSelectedTicketType = By.xpath("//button[@class='btn move btn-WorldLineBlue']");

	public static By SelectPopularTicketTypeoption = By.xpath("//a[@id='DivPopularTicketTypes-tab']");
	public static By PopularTicketType_OrgDropdown = By.xpath("//select[@id='OrganisationPopularTktTypeFilter']");
	public static By Edit_PopularTicketType = By.xpath("//*[@id='tablePopularTicketTypesLists']//*[@class='btn btnEdit']");
	public static By HeaderforPopularTicketType = By.xpath("//h1[contains(text(), 'Edit Popular Ticket Types List')]");
	public static By AddPopularTicketType = By.xpath("//*[@name='UnSelectedItems_SelectedTicketTypesIds']//*[@value='3478']");

	public static By MoveSelectedPopularTicketType = By.xpath("//button[@class='btn move btn-WorldLineBlue']");
	public static By ExcludedTicket_Filter = By.xpath("//div[@class='box1 col-md-6']//*[@class='filter form-control']");
	public static By AddExcludedTicketType1 = By.xpath("//*[@id='bootstrap-duallistbox-nonselected-list_SelectItemTicketTypes']//*[@value='3204']");
	public static By AddExcludedTicketType2 = By.xpath("//select[@name='SelectItemTicketTypes_helper1']//option[@value='3204']");
	public static By AddExcludedTicketType = By.xpath("//select[@class='form-control']//option[@value='3204']");
	public static By PopularTicket_Filter = By.xpath("//div[@class='box1 col-md-6']//*[@class='filter form-control']");

	public static By RemovRailcard_2TS = By.xpath("//a[@class='close _liclose']");
	public static By RemovedRailcard = By.xpath("//button[@class='btn removeall btn-WorldLineBlue']");
	public static By RemoveRoutes = By.xpath("//*[@name='SelectItemRoutesEdit_helper2']//option[text()='00011 - RAIL ONLY']");

	public static By RemovedRoutes = By.xpath("//button[@class='btn remove btn-WorldLineBlue']");
	public static By RemoveExcludedTicketType = By.xpath("//select[@name='SelectItemTicketTypes_helper2']//option[@value='3204']");
	public static By MovedSelectedTicketType = By.xpath("//button[@class='btn remove btn-WorldLineBlue']");
	public static By RemovePopularTicketType = By.xpath("//a[@class='close _liclose']");
	public static By SOS = By.xpath("//input[@id='Filter_2_SelectedTicketTypesIds']");

	public static By AddExcludeRoutes = By.xpath("//*[@name='SelectItemRoutesEdit_helper1']//*[@value='15']");

	public static By SelectPopularLocationOption = By.xpath("//a[@id='DivPopularDestinations-tab']");
	public static By PopularLocation_OrgDropdown = By.xpath("//select[@id='OrganisationPopularDestFilter']");
	public static By Edit_PopularLocation = By.xpath("//*[@id='tablePopularDestinationLists']//*[@class='btn btnEdit']");
	public static By HeaderforPopularLocation = By.xpath("//h1[contains(text(), 'Edit Popular Destinations List')]");
	public static By PopularLocation_Filter = By.xpath("//div[@class='box1 col-md-6']//*[@class='filter form-control']");
	
	public static By PopularLocation_Filter1 = By.xpath("//input[@id='Filter_1_SelectedOrgLocationIds']");
	
	public static By AddPopularLocation = By.xpath("//*[@name='UnSelectedItems_SelectedOrgLocationIds']//*[@value='8263']");

	public static By RemoveExcludedLocation = By.xpath("//select[@name='SelectItemTicketTypes_helper2']//option[@value='3204']");
	public static By MovedSelectedLocation = By.xpath("//button[@class='btn remove btn-WorldLineBlue']");

	public static By RemovePopularLocation_Filter = By.xpath("//input[@id='Filter_2_SelectedOrgLocationIds']");

	// 00002 - Not other Zone
	public static By SelectRoute = By.xpath("//select[@name='SelectItemRoutesEdit_helper1']//option[@value='5']");
	public static By RemoveRoute = By.xpath("//select[@name='SelectItemRoutesEdit_helper2']//option[@value='5']");
	public static By MovedRemovedRoute = By.xpath("//button[@class='btn remove btn-WorldLineBlue']");

	// Market Text Header and Footer
	public static By Config = By.xpath("//a[@id='TabAppConfig']");
	public static By MarketingText_Option = By.xpath("//a[@id='Marketing-Text-tab']");
	public static By MarketingText_Org = By.xpath("//select[@id='organisationFilterMT']");
	public static By MarketingText_Edit = By.xpath("//*[@id='tableMarketingText']//*[@class='btn btnEdit']");
	public static By MarketingTextPopupHeader = By.xpath("//h1[contains(text(), 'Edit Marketing Text')]");
	public static By MarketingTextHeaderField = By.xpath("//*[@id='MarketingTextHeader']");
	public static By MarketingTextFooterField = By.xpath("//*[@id='MarketingTextFooter']");
	public static By MarketingTextChangesSave = By.xpath("//*[@id='btnSubmit']");
	
	public static By RemovePopularLoc = By.xpath("//li[@class='list-group-item sorting-initialize ui-sortable-handle'][2]//a[@class='close _liclose']");
	 
	public static By RemovePopularTicket = By.xpath("//ul[@id='SelectedItems_SelectedTicketTypesIds']//li[@class='list-group-item sorting-initialize ui-sortable-handle'][2]//a[@class='close _liclose']");
	//public static By RemovePopularTicket = By.xpath("//li[@class='list-group-item sorting-initialize ui-sortable-handle']//a[@class='close _liclose']");
	public static By RemovePopularTicket1 = By.xpath("//li[@class='list-group-item sorting-initialize ui-sortable-handle'][2]//a[@class='close _liclose']");
//****************************************************************************************************************************************

	// Change the asset details and ticket types From console
	public static void user_Change_the_asset_details_and_ticket_types_From_console() {
		try {
			GET_Configuration.ConsoleLogin();
			GET_Configuration.ChangeOrganisationDetails();
			GET_Configuration.AddPopularRailcard();
			GET_Configuration.AddExcludedRoutes();
			GET_Configuration.AddExcludedTicketType();
			GET_Configuration.AddPopularTicketType();
			GET_Configuration.AddPopularLocations();
			GET_Configuration.addMarketingTextHeaderAndFooterintoOrganisationDetailsSection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Remove the added ticket types and run the endpoint URL
	public static void remove_the_added_ticket_types_and_run_the_endpoint_URL() {
		try {
			GET_Configuration.ConsoleLogin();
			GET_Configuration.updateDefaultOrganisationDetails();
			GET_Configuration.RemovePopularRailcard();
			GET_Configuration.RemoveExcludedRoutes();
			GET_Configuration.RemoveExcludedTicketType();
			GET_Configuration.RemovePopularTicketType();
			GET_Configuration.RemovePopularLocations();
			GET_Configuration.removeMarketingTextHeaderAndFooterintoOrganisationDetailsSection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Run Configuration API call and check the Asset Details
	public static void getConfigurationResponse(LinkedHashMap<String, String> linkedHashMap) throws Exception {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println("Get Configuration Response is :" + ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment("Get Configuration Response",
					"Get Configuration API run successfully and response is as below: \n" + ConfigurationResponse);
			Allure.attachment("Configuration API Response",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}

	// Verify The changes should reflect and should be shown correctly
	public static void verify_The_changes_should_reflect_and_should_be_shown_correctly(
			LinkedHashMap<String, String> linkedHashMap) {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println(
					"The Asset, Organisation details and ticket types changes Reflected : " + ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment("Organisations details - VAT No, Marketing Text and ticket type changes Reflected",
					"Organisations details - VAT No, Marketing Text and ticket type changes Reflected successfully and response is as below: \n"
							+ ConfigurationResponse);
			Allure.attachment(
					"Organisations details - VAT No, Marketing Text and ticket type changes Reflected - Status",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}

	// Verify the Removed ticket types changes Reflected into Console")
	public static void verify_the_Removed_ticket_types_changes_Reflected_into_Console(
			LinkedHashMap<String, String> linkedHashMap) {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println(
					"Org details updated with Default VAT No, Marketing Text and added ticket types Removed from Console"
							+ ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment(
					"Org details updated with Default VAT No, Marketing Text and added ticket types Removed from Console",
					"Removed changes Reflected successfully and response is as below: \n" + ConfigurationResponse);
			Allure.attachment("Org details and Removed changes Reflected - Status",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}

//******************************************Add Ticket Types*************************************************************//

	public static void ConsoleLogin() {
		try {
			ChromeOptions chromeOptions = new ChromeOptions();
			WebDriverManager.chromedriver().setup();
		    driver = new ChromeDriver(chromeOptions);
		    driver.get(prop.getProperty("ConsoleURL"));
			driver.manage().window().maximize();
			driver.findElement(By.id("LogonId")).sendKeys("Asnow");
			driver.findElement(By.id("LoginPasscode")).sendKeys("Worldline@12345");
//			TestBase.ScreenshotStep("User entered Login Details on Console Login page Successfully");
			driver.findElement(By.xpath("//button[@title='Login']")).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Change Organisation Details
	public static void ChangeOrganisationDetails() {
		try {
			waitForElement(AdminData, explicitWait,"ELEMENTTOBECLICKABLE" );
//			TestBase.ScreenshotStep("User Login on Console Successfully");
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			WebElement ele = driver.findElement(AdminData);
			executor.executeScript("arguments[0].click();", ele);
			waitForElement(AdminDataPageLayout, explicitWait,"ELEMENTTOBECLICKABLE" );
//			TestBase.ScreenshotStep("Default Admin Data Page Layout");
			Select org = new Select(driver.findElement(By.id("ddlAdminDataList")));	
			org.selectByIndex(15);
			Thread.sleep(4000);
			// scroll till pagination-info
			WebElement element = driver.findElement(By.xpath("//span[@class='pagination-info']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(3000);
			String cssSelectorOfSameElements = "button[type='button'][class='btn btnEdit']";
			List<WebElement> a = driver.findElements(By.cssSelector(cssSelectorOfSameElements));
			a.get(26).click();
			waitForElement(EditOrgRow, explicitWait,"ELEMENTTOBECLICKABLE" );
			driver.findElement(VAT_No).clear();
			driver.findElement(VAT_No).sendKeys("230505848");
//			TestBase.ScreenshotStep("VAT No has been updated Successfully");
			Thread.sleep(3000);
			WebElement scrollTillSaveBtn = driver.findElement(By.xpath("//button[@id='btnSave']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", scrollTillSaveBtn);
			Thread.sleep(2000);
			driver.findElement(Save_Btn).click();
			waitForElement(AdminData, explicitWait,"ELEMENTTOBECLICKABLE" );
			System.out.println("VAT No has been changed Successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Add Popular Railcard - 2TS
	public static void AddPopularRailcard() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			JavascriptExecutor executor1 = (JavascriptExecutor) driver;
			WebElement ele1 = driver.findElement(appConfigButton);
			executor1.executeScript("arguments[0].click();", ele1);
			wait.until(ExpectedConditions.visibilityOfElementLocated(AppConfigurePage));
//			TestBase.ScreenshotStep("Default App Config Page Layout");
			driver.findElement(Favourites).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SelectPopularRailcardoption));
			driver.findElement(SelectPopularRailcardoption).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(OrgDropdown));
			Select Selectorg = new Select(
					driver.findElement(By.xpath("//select[@id='OrganisationDiscountCodesFilter']")));
			Selectorg.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(edit1);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(Header));
			driver.findElement(AddpopularRailcard).click();
			Thread.sleep(3000);
			driver.findElement(MoveSelectedRailcard).click();
//			TestBase.ScreenshotStep("Popular Railcard - 2TS, Moved");
			driver.findElement(Save).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeList_Tab));
//			TestBase.ScreenshotStep("Popular Railcard - 2TS, Added successfully");
			System.out.println("Popular Railcard - 2TS, Added successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Add Exclude Routes - 00002 - Not other Zone
	public static void AddExcludedRoutes() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			driver.findElement(ExcludeList_Tab).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeRoutes_option));
			Thread.sleep(2000);
			driver.findElement(ExcludeRoutes_option).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeList_OrgDropdown));
			Thread.sleep(2000);
			Select Selectorg1 = new Select(driver.findElement(By.xpath("//select[@id='OrganisationERTListFilter']")));
			Selectorg1.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(editRoute);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(HeaderforExcludeRoute));
			Thread.sleep(3000);
			driver.findElement(SelectRoute).click(); // 00002 - Not other Zone
			Thread.sleep(3000);
			driver.findElement(MoveSelectedRoutes).click();
			driver.findElement(Save).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeList_Tab));
//			TestBase.ScreenshotStep("Exclude Routes - '00011 - RAIL ONLY', Added successfully");
			System.out.println("Exclude Routes - '00002 - Not other Zone', Added successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Add Excluded Ticket Type - HOR - ANYTIME R
	public static void AddExcludedTicketType() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			driver.findElement(ExcludeList_Tab).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeTicketType));
			Thread.sleep(2000);
			driver.findElement(ExcludeTicketType).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludedTicketType_OrgDropdown));
			Select Selectorg1 = new Select(driver.findElement(By.xpath("//select[@id='OrganisationETTListFilter']")));
			Selectorg1.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(Edit_ExcludedTicketType);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(HeaderforExcludeTicketType));
//			wait.until(ExpectedConditions.elementToBeClickable(AddExcludedTicketType2));
			Thread.sleep(2000);
			driver.findElement(AddExcludedTicketType2).click();
			Thread.sleep(2000);
			driver.findElement(MoveSelectedTicketType).click();
//			TestBase.ScreenshotStep("Excluded Ticket Type - HOR - ANYTIME R, Moved");
			driver.findElement(Save).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeList_Tab));
//			TestBase.ScreenshotStep("Excluded Ticket Type - HOR - ANYTIME R, Added successfully");
			System.out.println("Excluded Ticket Type - HOR - ANYTIME R, Added successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Add Popular Ticket Type - SOS - ANYTIME S
	public static void AddPopularTicketType() {
		try {
//			WebDriverWait wait = new WebDriverWait(driver, 120);
//			JavascriptExecutor executor1 = (JavascriptExecutor) driver;
//			WebElement ele1 = driver.findElement(appConfigButton);
//			executor1.executeScript("arguments[0].click();", ele1);
//			wait.until(ExpectedConditions.visibilityOfElementLocated(AppConfigurePage));
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 120);
			driver.findElement(Favourites).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SelectPopularTicketTypeoption));
			Thread.sleep(3000);
			driver.findElement(SelectPopularTicketTypeoption).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(PopularTicketType_OrgDropdown));
			Select Selectorg1 = new Select(
					driver.findElement(By.xpath("//select[@id='OrganisationPopularTktTypeFilter']")));
			Selectorg1.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(Edit_PopularTicketType);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(HeaderforPopularTicketType));
			Thread.sleep(10000);
//			driver.findElement(PopularTicket_Filter).clear();
			driver.findElement(PopularTicket_Filter).click();
			driver.findElement(PopularTicket_Filter).sendKeys("SOS - ANYTIME S");
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(AddPopularTicketType));
			Thread.sleep(2000);
			driver.findElement(AddPopularTicketType).click();
			Thread.sleep(3000);
			driver.findElement(MoveSelectedPopularTicketType).click();
//			TestBase.ScreenshotStep("Excluded Ticket Type - SOS - ANYTIME S, Moved");
			driver.findElement(Save).click();
			Thread.sleep(12000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(Favourites));
//			TestBase.ScreenshotStep("Excluded Ticket Type - SOS - ANYTIME S, Added successfully");
			System.out.println("Popular Ticket Types List - SOS - ANYTIME S, Added successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Add Popular Locations - YORK (8263)
	public static void AddPopularLocations() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			driver.findElement(Favourites).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SelectPopularLocationOption));
			Thread.sleep(3000);
			driver.findElement(SelectPopularLocationOption).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(PopularLocation_OrgDropdown));
			Select Selectorg1 = new Select(
					driver.findElement(By.xpath("//select[@id='OrganisationPopularDestFilter']")));
			Selectorg1.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(Edit_PopularLocation);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(HeaderforPopularLocation));
			Thread.sleep(10000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(PopularLocation_Filter1));
			if(isElementPresent(PopularLocation_Filter)) {
				driver.findElement(PopularLocation_Filter).click();
				driver.findElement(PopularLocation_Filter).sendKeys("8263"); // YORK (8263)
			}else {
				driver.findElement(PopularLocation_Filter1).click();
				driver.findElement(PopularLocation_Filter1).sendKeys("8263"); // YORK (8263)
			}
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(AddPopularLocation));
			Thread.sleep(2000);
			driver.findElement(AddPopularLocation).click();
			Thread.sleep(2000);
			driver.findElement(MoveSelectedPopularTicketType).click();
//			TestBase.ScreenshotStep("Popular Locations - YORK (8263), Moved");
			driver.findElement(Save).click();
			Thread.sleep(10000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(Favourites));
//			TestBase.ScreenshotStep("Popular Locations - YORK (8263), Added successfully");
			System.out.println("Popular Locations - YORK (8263), Added successfully");
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// add Marketing Text Header And Footer into Organisation Details Section
	public static void addMarketingTextHeaderAndFooterintoOrganisationDetailsSection() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
//			JavascriptExecutor executor1 = (JavascriptExecutor) driver;
//			WebElement ele1 = driver.findElement(appConfigButton);
//			executor1.executeScript("arguments[0].click();", ele1);
//			wait.until(ExpectedConditions.visibilityOfElementLocated(AppConfigurePage));
			wait.until(ExpectedConditions.visibilityOfElementLocated(Config));
			driver.findElement(Config).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarketingText_Option));
			driver.findElement(MarketingText_Option).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarketingText_Org));

			Select Selectorg = new Select(driver.findElement(By.xpath("//select[@id='organisationFilterMT']")));
			Selectorg.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(MarketingText_Edit);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarketingTextPopupHeader));
			Thread.sleep(5000);
			driver.findElement(MarketingTextHeaderField).clear();
			driver.findElement(MarketingTextHeaderField).sendKeys("Thank you for your purchase!");
			driver.findElement(MarketingTextFooterField).clear();
			driver.findElement(MarketingTextFooterField).sendKeys("Have a nice day!");
			Thread.sleep(3000);
			WebElement scrollTillSaveBtn = driver.findElement(By.xpath("//*[@id='btnSubmit']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", scrollTillSaveBtn);
			Thread.sleep(2000);
			driver.findElement(MarketingTextChangesSave).click();
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarketingText_Org));
			System.out.println("Marketing Text Header and Footer Added Successfully");
			Thread.sleep(3000);
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

// ******************************************Remove Ticket Types*************************************************************//

	// update Default Organisation Details
	public static void updateDefaultOrganisationDetails() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.visibilityOfElementLocated(AdminData));
//			TestBase.ScreenshotStep("User Login on Console Successfully");
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			WebElement ele = driver.findElement(AdminData);
			executor.executeScript("arguments[0].click();", ele);
			wait.until(ExpectedConditions.visibilityOfElementLocated(AdminDataPageLayout));
//			TestBase.ScreenshotStep("Default Admin Data Page Layout");
			Select org = new Select(driver.findElement(By.id("ddlAdminDataList")));
			org.selectByIndex(15);
			Thread.sleep(4000);
			// scroll till pagination-info
			WebElement element = driver.findElement(By.xpath("//span[@class='pagination-info']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(3000);
			String cssSelectorOfSameElements = "button[type='button'][class='btn btnEdit']";
			List<WebElement> a = driver.findElements(By.cssSelector(cssSelectorOfSameElements));
			a.get(26).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(EditOrgRow));
			driver.findElement(VAT_No).clear();
			driver.findElement(VAT_No).click();
			driver.findElement(VAT_No).sendKeys("230505846");
//			TestBase.ScreenshotStep("Removed updated VAT No and keeping as Default one Successfully");
			Thread.sleep(3000);
			WebElement scrollTillSaveBtn = driver.findElement(By.xpath("//button[@id='btnSave']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", scrollTillSaveBtn);
			Thread.sleep(2000);
			driver.findElement(Save_Btn).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(AdminData));
			System.out.println("Removed updated VAT No and keeping as Default one Successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Remove Popular Railcard - 2TS
	public static void RemovePopularRailcard() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			JavascriptExecutor executor1 = (JavascriptExecutor) driver;
			WebElement ele1 = driver.findElement(appConfigButton);
			executor1.executeScript("arguments[0].click();", ele1);
			wait.until(ExpectedConditions.visibilityOfElementLocated(AppConfigurePage));
//			TestBase.ScreenshotStep("Default App Config Page Layout");
			driver.findElement(Favourites).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SelectPopularRailcardoption));
			driver.findElement(SelectPopularRailcardoption).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(OrgDropdown));
			Select Selectorg = new Select(
					driver.findElement(By.xpath("//select[@id='OrganisationDiscountCodesFilter']")));
			Selectorg.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");

			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(edit1);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);

			wait.until(ExpectedConditions.visibilityOfElementLocated(Header));
			Thread.sleep(7000);
			List<WebElement> a = driver.findElements(By.xpath("//a[@class='close _liclose']"));
			a.get(1).click();
//			TestBase.ScreenshotStep("Popular Railcard - 2TS, Moved");
			driver.findElement(Save).click();
			Thread.sleep(8000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeList_Tab));
//			TestBase.ScreenshotStep("Popular Railcard - 2TS, Added successfully");
			System.out.println("Popular Railcard - 2TS, Removed successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Remove Exclude Routes -00002 - Not other Zone
	public static void RemoveExcludedRoutes() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			driver.findElement(ExcludeList_Tab).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeRoutes_option));
			Thread.sleep(2000);
			driver.findElement(ExcludeRoutes_option).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeList_OrgDropdown));
			Thread.sleep(2000);
			Select Selectorg1 = new Select(driver.findElement(By.xpath("//select[@id='OrganisationERTListFilter']")));
			Selectorg1.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(editRoute);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(HeaderforExcludeRoute));
			Thread.sleep(8000);
			driver.findElement(RemoveRoute).click(); // 00002 - Not other Zone
			Thread.sleep(2000);
			driver.findElement(MovedRemovedRoute).click();
			Thread.sleep(2000);
			driver.findElement(Save).click();
			Thread.sleep(7000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeList_Tab));
//			TestBase.ScreenshotStep("Exclude Routes -'00011 - RAIL ONLY', Removed successfully");
			System.out.println("Exclude Routes - '00002 - Not other Zone', Removed successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Remove Excluded Ticket Type - HOR - ANYTIME R
	public static void RemoveExcludedTicketType() {
		try {
			
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 120);
			driver.findElement(ExcludeList_Tab).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeTicketType));
			Thread.sleep(2000);
			driver.findElement(ExcludeTicketType).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludedTicketType_OrgDropdown));
			Select Selectorg1 = new Select(driver.findElement(By.xpath("//select[@id='OrganisationETTListFilter']")));
			Selectorg1.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(Edit_ExcludedTicketType);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(HeaderforExcludeTicketType));
			Thread.sleep(7000);
			driver.findElement(RemoveExcludedTicketType).click();
			Thread.sleep(3000);
			driver.findElement(MovedSelectedTicketType).click();
//			TestBase.ScreenshotStep("Excluded Ticket Type - HOR - ANYTIME R, Removed");
			driver.findElement(Save).click();
			Thread.sleep(7000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(ExcludeList_Tab));
//			TestBase.ScreenshotStep("Excluded Ticket Type - HOR - ANYTIME R, Added successfully");
			System.out.println("Excluded Ticket Type - HOR - ANYTIME R, Removed successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Remove Popular Ticket Type - SOS - ANYTIME S
	public static void RemovePopularTicketType() {
		try {
//			WebDriverWait wait = new WebDriverWait(driver, 120);
//			JavascriptExecutor executor1 = (JavascriptExecutor) driver;
//			WebElement ele1 = driver.findElement(appConfigButton);
//			executor1.executeScript("arguments[0].click();", ele1);
//			wait.until(ExpectedConditions.visibilityOfElementLocated(AppConfigurePage));
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 120);
			driver.findElement(Favourites).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SelectPopularTicketTypeoption));
			Thread.sleep(3000);
			driver.findElement(SelectPopularTicketTypeoption).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(PopularTicketType_OrgDropdown));
			Select Selectorg1 = new Select(
					driver.findElement(By.xpath("//select[@id='OrganisationPopularTktTypeFilter']")));
			Selectorg1.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(Edit_PopularTicketType);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(HeaderforPopularTicketType));
			Thread.sleep(10000);
			if(isElementPresent(RemovePopularTicket)) {
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(RemovePopularTicket));
			driver.findElement(RemovePopularTicket).click();
			}
			else {
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOfElementLocated(RemovePopularTicket1));
				driver.findElement(RemovePopularTicket1).click();
			}
            Thread.sleep(2000);
//			driver.findElement(SOS).sendKeys("SOS");
//			List<WebElement> removePTT = driver.findElements(By.xpath("//a[@class='close _liclose']"));
//			removePTT.get(1).click();
////			TestBase.ScreenshotStep("Excluded Ticket Type - SOS - ANYTIME S, Moved");
			driver.findElement(Save).click();
			Thread.sleep(7000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(Favourites));
//			TestBase.ScreenshotStep("Excluded Ticket Type - SOS - ANYTIME S, Removed successfully");
			System.out.println("Popular Ticket Types List - SOS - ANYTIME S, Removed successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Remove Popular Locations - YORK (8263)
	public static void RemovePopularLocations() {
		try {
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 120);
			driver.findElement(Favourites).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(SelectPopularLocationOption));
			Thread.sleep(3000);
			driver.findElement(SelectPopularLocationOption).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(PopularLocation_OrgDropdown));
			Select Selectorg1 = new Select(
					driver.findElement(By.xpath("//select[@id='OrganisationPopularDestFilter']")));
			Selectorg1.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(Edit_PopularLocation);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(HeaderforPopularLocation));
			Thread.sleep(10000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(RemovePopularLoc));
			driver.findElement(RemovePopularLoc).click();
            Thread.sleep(2000);
			driver.findElement(Save).click();
			Thread.sleep(7000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(Favourites));
//			TestBase.ScreenshotStep("Popular Locations - YORK (8263), Added successfully");
			System.out.println("Popular Locations - YORK (8263), Added successfully");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Remove Marketing Text Header And Footer into Organisation Details Section
	public static void removeMarketingTextHeaderAndFooterintoOrganisationDetailsSection() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			JavascriptExecutor executor1 = (JavascriptExecutor) driver;
			WebElement ele1 = driver.findElement(appConfigButton);
			executor1.executeScript("arguments[0].click();", ele1);
			wait.until(ExpectedConditions.visibilityOfElementLocated(AppConfigurePage));
			driver.findElement(Config).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarketingText_Option));
			driver.findElement(MarketingText_Option).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarketingText_Org));

			Select Selectorg = new Select(driver.findElement(By.xpath("//select[@id='organisationFilterMT']")));
			Selectorg.selectByValue("80");
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)", "");
			JavascriptExecutor ClickonEdit = (JavascriptExecutor) driver;
			WebElement Edit_Btn = driver.findElement(MarketingText_Edit);
			ClickonEdit.executeScript("arguments[0].click();", Edit_Btn);
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarketingTextPopupHeader));
			Thread.sleep(7000);
			driver.findElement(MarketingTextHeaderField).clear();
			driver.findElement(MarketingTextHeaderField).sendKeys("Not yet added");
			driver.findElement(MarketingTextFooterField).clear();
			driver.findElement(MarketingTextFooterField).sendKeys("Not added");
			Thread.sleep(3000);
			WebElement scrollTillSaveBtn = driver.findElement(By.xpath("//*[@id='btnSubmit']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", scrollTillSaveBtn);
			Thread.sleep(2000);
			driver.findElement(MarketingTextChangesSave).click();
			Thread.sleep(7000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(MarketingText_Org));
			System.out.println("Marketing Text Header and Footer Removed Successfully");
			Thread.sleep(3000);
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//**************************************************Seperate out configuration API call************************************************
	// Configuration API for Asset Details validation
	public static void getConfigurationResponseForAssetDetails(LinkedHashMap<String, String> linkedHashMap) throws Exception {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration/asset");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println("Get Configuration Response for Asset is :" + ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment("Get Configuration Response",
					"Get Configuration API run successfully and response is as below: \n" + ConfigurationResponse);
			Allure.attachment("Configuration API Response",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}
	
	// Configuration API for Organisation Details validation
	public static void getConfigurationResponseForOrganisationDetails(LinkedHashMap<String, String> linkedHashMap) throws Exception {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration/organisationdetails");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println("Get Configuration Response for Organisation Details is :" + ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment("Get Configuration Response",
					"Get Configuration API run successfully and response is as below: \n" + ConfigurationResponse);
			Allure.attachment("Configuration API Response",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}
	
	// Configuration API for Popular ticket types validation
	public static void getConfigurationResponseForPopularTicketTypes(LinkedHashMap<String, String> linkedHashMap) throws Exception {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration/populartickettypes");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println("Get Configuration Response for Popular ticket types is :" + ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment("Get Configuration Response",
					"Get Configuration API run successfully and response is as below: \n" + ConfigurationResponse);
			Allure.attachment("Configuration API Response",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}

	// Configuration API for Popular locations details validation
	public static void getConfigurationResponseForPopularLocationsDetails(LinkedHashMap<String, String> linkedHashMap) throws Exception {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration/popularlocations");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println("Get Configuration Response for Popular locations details is :" + ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment("Get Configuration Response",
					"Get Configuration API run successfully and response is as below: \n" + ConfigurationResponse);
			Allure.attachment("Configuration API Response",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}
	
	// Configuration API for Popular Railcards details validation
	public static void getConfigurationResponseForPopularRailcards(LinkedHashMap<String, String> linkedHashMap) throws Exception {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration/popularrailcards");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println("Get Configuration Response for Popular Railcards details is :" + ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment("Get Configuration Response",
					"Get Configuration API run successfully and response is as below: \n" + ConfigurationResponse);
			Allure.attachment("Configuration API Response",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}
	
	// Configuration API for Excluded ticket types details validation
	public static void getConfigurationResponseForExcludedTicketTypes(LinkedHashMap<String, String> linkedHashMap) throws Exception {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration/excludedtickettypes");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println("Get Configuration Response for Excluded ticket types details is :" + ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment("Get Configuration Response",
					"Get Configuration API run successfully and response is as below: \n" + ConfigurationResponse);
			Allure.attachment("Configuration API Response",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}
	
	// Configuration API for Excluded routes details validation
	public static void getConfigurationResponseForExcludedRoutes(LinkedHashMap<String, String> linkedHashMap) throws Exception {
		try {
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();

			Response response = request.given().header("TisId", linkedHashMap.get("tisid"))
					.header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/configuration/excludedroutes");

			ResponseBody respbody = response.getBody();
			ConfigurationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Configuration Response" + cook);
			System.out.println("Get Configuration Response for Excluded routes details is :" + ConfigurationResponse);

			GetConfigurationResponseStatuscode = response.getStatusCode();
			softassert8.assertEquals(response.getStatusCode(), 200);
			System.out.println("Get Configuration Response started successfully and the status is 200 as Expected: "
					+ GetConfigurationResponseStatuscode);

			Allure.attachment("Get Configuration Response",
					"Get Configuration API run successfully and response is as below: \n" + ConfigurationResponse);
			Allure.attachment("Configuration API Response",
					"Response Status as : \n" + GetConfigurationResponseStatuscode);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Get Configuration API Response",
					"Get Configuration API couldn't run successfully and Error is as shown below: \n"
							+ ConfigurationResponse);
		}

	}
}
