//Auther : shantanu devkar

package Evoke.pageobject;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.client.ClientProtocolException;
import org.json.simple.JSONObject;
import org.openqa.selenium.json.JsonException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Evoke.utilities.TestBase;
import groovyjarjarasm.asm.Type;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

public class ErrorCodeVerification extends TestBase {
	public static String Tisid;
	public static String cook;
	public static String InvalidTisIdResponse;
	public static String BlankTisIdResponse;
	public static int InvalidTisIdResponseStatuscode;
	public static int BlankTisIdResponseStatuscode;
	public static String emptyBodyResponse;
	public static String InvalidBasketResponse;
	public static String ProcessTranxwithoutShiftResponse;
	public static String MandatoryReservationResponse;
	public static int emptyBodyResponseStatuscode;
	public static int MandatoryReservationStatuscode;
	public static int ProcessTranxwithoutShiftResponseStatuscode;
	public static String ProcessTranxwithoutPaymentDetailsResp;
	public static int ProcessTranxwithoutPaymentDetailsResponseStatuscode;
	public static String PaymentNotMatchedWithBasketResp;
	public static int PaymentNotMatchedWithBasketStatuscode;
	public static String PaymentwithInvalidReferenceResp;
	public static int PaymentwithInvalidReferenceRespStatuscode;
	public static String PastTripResponse;
	public static int PastTripResponseStatuscode;
	public static RequestSpecification req;
	public static String SourceLoc;
	public static String DestinationLoc;

	public static String InvalidMaskPANResponse;
	public static int InvalidMaskPANResponseStatuscode;
	public static String Couponlink = null;
	public BufferedImage image = null;
	public static byte[] imageByte;
	public static byte[] imageByte1;
	public static Response response;
	public static Response respbody;
	public static String totalcost = GET_Customer_Basket_Response.totalAmount;

	public static void blankTiSId(LinkedHashMap<String, String> linkedHashMap) {

		try {
			SourceLoc = linkedHashMap.get("sourceLoc");
			DestinationLoc = linkedHashMap.get("desLoc");
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			Response response = request.given().header("content-Type", linkedHashMap.get("Content-Type")).with()
					.body(postcontent).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/shift/start");

			ResponseBody respbody = response.getBody();
			BlankTisIdResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Invalid Tis Id response is :" + BlankTisIdResponse);

			BlankTisIdResponseStatuscode = response.getStatusCode();
			softassert1.assertEquals(BlankTisIdResponseStatuscode, 1001);
			System.out.println("Blank Tis Id response is 1001 as Expected: " + BlankTisIdResponseStatuscode);
			Allure.addAttachment("Start Shift Started => " + SourceLoc + " To " + DestinationLoc, BlankTisIdResponse);
			Allure.attachment("Start Shift Response for Blank Tis Id", "Response Status as : \n" + BlankTisIdResponse);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Start Shift Response",
					"Start Shift couldn't run successfully and Error is as shown below: \n" + InvalidTisIdResponse);
		}

	}

	public static void emptyBody(LinkedHashMap<String, String> linkedHashMap) {

		try {
			SourceLoc = linkedHashMap.get("sourceLoc");
			DestinationLoc = linkedHashMap.get("desLoc");
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			// System.out.println(request);
			String tisid = linkedHashMap.get("tisid");
			Response response = request.given().header("TisId", tisid)
					.header("content-Type", linkedHashMap.get("Content-Type")).with().body(postcontent).auth()
					.preemptive().basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log()
					.all().post("/shift/start");

			ResponseBody respbody = response.getBody();
			emptyBodyResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Empty Body response is :" + emptyBodyResponse);

			emptyBodyResponseStatuscode = response.getStatusCode();
			softassert1.assertEquals(emptyBodyResponseStatuscode, 2005);
			System.out.println("Empty Body response is 1001 as Expected: " + emptyBodyResponseStatuscode);
			Allure.addAttachment("Start Shift Started => " + SourceLoc + " To " + DestinationLoc, emptyBodyResponse);
			Allure.attachment("Start Shift Response for Empty Body", "Response Status as : \n" + emptyBodyResponse);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Start Shift Response",
					"Start Shift couldn't run successfully and Error is as shown below: \n" + InvalidTisIdResponse);
		}

	}

	public static void InvalidMaskPAN(LinkedHashMap<String, String> linkedHashMap) throws ClientProtocolException {

		try {
			totalcost = GET_Customer_Basket_Response.totalAmount;
			System.out.println("Total Cost is: " + totalcost);
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			ArrayList<JSONObject> array = new ArrayList<JSONObject>();
			JSONObject json = new JSONObject();

			try {
				json.put("key", "value");// your json
			} catch (JsonException e) {
				e.printStackTrace();
			}
			array.add(json);
			String printjsonarray = array.toString();// pass this into the request

			Map<String, Object> map = new LinkedHashMap<>();

			map.put("retailHubBasket", GET_Customer_Basket_Response.sbasket);
			map.put("cardPayments", Arrays.asList(new LinkedHashMap<String, Object>() {
				{
					put("cardReference", "string");
					put("issueNumber", "string");
					put("startMMYY", "string");
					put("expiryMMYY", "string");
					put("maskedPAN", "12345556123#");
					put("amount", totalcost.toString());

				}
			}));

			ArrayList<String> newprinters_CCSTNewbury = new ArrayList<String>();
			newprinters_CCSTNewbury.add("CCSTNewbury");
			map.put("fulfilmentConfiguration", (new LinkedHashMap<String, Object>() {
				{
					put("availablePrinters", newprinters_CCSTNewbury);
					put("hopperType", "Internal");

				}

			}));
			String tisid = linkedHashMap.get("tisid");
			response = request.given().header("TisId", tisid).header("content-Type", linkedHashMap.get("Content-Type"))
					.with().body(map).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/transaction/process");

			ResponseBody respbody = response.getBody();
			InvalidMaskPANResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Invalid Mask PAN response is :" + InvalidMaskPANResponse);

			InvalidMaskPANResponseStatuscode = response.getStatusCode();
			softassert5.assertEquals(response.getStatusCode(), 3019);
			System.out.println("Process Transaction done successfully and the status is 200 as Expected: "
					+ InvalidMaskPANResponseStatuscode);

			Allure.attachment("Invalid Mask PAN Response",
					"ProcessTransaction run successfully and response is as below: \n" + InvalidMaskPANResponse);
			Allure.attachment("Invalid Mask PAN Response Status",
					"Response Status as : \n" + InvalidMaskPANResponseStatuscode);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Invalid Mask PAN Response",
					"Process Transaction couldn't run successfully and Error is as shown below: \n"
							+ InvalidMaskPANResponseStatuscode);
		}

	}

	public static void invalidBasketResponse(LinkedHashMap<String, String> linkedHashMap)
			throws ClientProtocolException {

		try {
			totalcost = GET_Customer_Basket_Response.totalAmount;
			System.out.println("Total Cost is: " + totalcost);
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			ArrayList<JSONObject> array = new ArrayList<JSONObject>();
			JSONObject json = new JSONObject();

			try {
				json.put("key", "value");// your json
			} catch (JsonException e) {
				e.printStackTrace();
			}
			array.add(json);
			String printjsonarray = array.toString();// pass this into the request

			Map<String, Object> map = new LinkedHashMap<>();

			map.put("retailHubBasket", GET_Customer_Basket_Response.sbasket);
			map.put("cardPayments", Arrays.asList(new LinkedHashMap<String, Object>() {
				{
					put("cardReference", "string");
					put("issueNumber", "string");
					put("startMMYY", "string");
					put("expiryMMYY", "string");
					put("maskedPAN", "123455561234");
					put("amount", totalcost.toString());

				}
			}));

			ArrayList<String> newprinters_CCSTNewbury = new ArrayList<String>();
			newprinters_CCSTNewbury.add("CCSTNewbury");
			map.put("fulfilmentConfiguration", (new LinkedHashMap<String, Object>() {
				{
					put("availablePrinters", newprinters_CCSTNewbury);
					put("hopperType", "Internal");

				}
			}));

			String tisid = linkedHashMap.get("tisid");
			response = request.given().header("TisId", tisid).header("content-Type", linkedHashMap.get("Content-Type"))
					.with().body(map).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/transaction/process");

			ResponseBody respbody = response.getBody();
			InvalidBasketResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Invalid Mask PAN response is :" + InvalidBasketResponse);

			InvalidMaskPANResponseStatuscode = response.getStatusCode();
			softassert5.assertEquals(response.getStatusCode(), 3005);
			Allure.attachment("Invalid Basket Response Status", "Response Status as : \n" + InvalidBasketResponse);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Invalid Mask PAN Response",
					"Process Transaction couldn't run successfully and Error is as shown below: \n"
							+ InvalidMaskPANResponseStatuscode);
		}

	}

	public static void processTransactionwithoutStartShift(LinkedHashMap<String, String> linkedHashMap)
			throws ClientProtocolException {

		try {
			totalcost = GET_Customer_Basket_Response.totalAmount;
			System.out.println("Total Cost is: " + totalcost);
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			ArrayList<JSONObject> array = new ArrayList<JSONObject>();
			JSONObject json = new JSONObject();

			try {
				json.put("key", "value");// your json
			} catch (JsonException e) {
				e.printStackTrace();
			}
			array.add(json);
			String printjsonarray = array.toString();// pass this into the request

			Map<String, Object> map = new LinkedHashMap<>();

			map.put("retailHubBasket", GET_Customer_Basket_Response.sbasket);
			map.put("cardPayments", Arrays.asList(new LinkedHashMap<String, Object>() {
				{
					put("cardReference", "string");
					put("issueNumber", "string");
					put("startMMYY", "string");
					put("expiryMMYY", "string");
					put("maskedPAN", "123455561234");
					put("amount", totalcost.toString());

				}
			}));


			ArrayList<String> newprinters = new ArrayList<String>();
			newprinters.add("PaperRoll");
			newprinters.add("CCSTNewbury");
			map.put("fulfilmentConfiguration", (new LinkedHashMap<String, Object>() {
				{
					put("availablePrinters", newprinters);
					put("hopperType", "Internal");

				}

			}));

			String tisid = linkedHashMap.get("tisid");
			response = request.given().header("TisId", tisid).header("content-Type", linkedHashMap.get("Content-Type"))
					.with().body(map).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/transaction/process");

			ResponseBody respbody = response.getBody();
			ProcessTranxwithoutShiftResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Process Transaction response is :" + ProcessTranxwithoutShiftResponse);

			ProcessTranxwithoutShiftResponseStatuscode = response.getStatusCode();
			softassert5.assertEquals(response.getStatusCode(), 3000);
			Allure.attachment("Process Transaction Run without Start Shift Response Status",
					"Response Status as : \n" + ProcessTranxwithoutShiftResponse);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Process Transaction Run without Start Shift",
					"Process Transaction couldn't run successfully and Error is as shown below: \n"
							+ ProcessTranxwithoutShiftResponseStatuscode);
		}

	}

	public static void processTransactionwithoutPaymentDetails(LinkedHashMap<String, String> linkedHashMap)
			throws ClientProtocolException {

		try {
			totalcost = GET_Customer_Basket_Response.totalAmount;
			System.out.println("Total Cost is: " + totalcost);
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			ArrayList<JSONObject> array = new ArrayList<JSONObject>();
			JSONObject json = new JSONObject();

			try {
				json.put("key", "value");// your json
			} catch (JsonException e) {
				e.printStackTrace();
			}
			array.add(json);
			String printjsonarray = array.toString();// pass this into the request

			Map<String, Object> map = new LinkedHashMap<>();
			
			//Card payment details not provided for 3015 error-added new code
			map.put("retailHubBasket", GET_Customer_Basket_Response.sbasket);
			ArrayList<String> newprinters = new ArrayList<String>();
			newprinters.add("PaperRoll");
			newprinters.add("CCSTNewbury");
			map.put("fulfilmentConfiguration", (new LinkedHashMap<String, Object>() {
				{
					put("availablePrinters", newprinters);
					put("hopperType", "Internal");

				}

			}));

			String tisid = linkedHashMap.get("tisid");
			response = request.given().header("TisId", tisid).header("content-Type", linkedHashMap.get("Content-Type"))
					.with().body(map).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/transaction/process");

			ResponseBody respbody = response.getBody();
			ProcessTranxwithoutPaymentDetailsResp = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Process Transaction response is :" + ProcessTranxwithoutPaymentDetailsResp);

			ProcessTranxwithoutPaymentDetailsResponseStatuscode = response.getStatusCode();
			softassert5.assertEquals(response.getStatusCode(), 3015);
			Allure.attachment("Process Transaction Run without Payment Details Response Status",
					"Response Status as : \n" + ProcessTranxwithoutPaymentDetailsResp);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Process Transaction Run without Payment Details",
					"Process Transaction couldn't run successfully and Error is as shown below: \n"
							+ ProcessTranxwithoutPaymentDetailsResp);
		}

	}

	public static void paymentNotMatchedWithBasket(LinkedHashMap<String, String> linkedHashMap)
			throws ClientProtocolException {

		try {
			totalcost = GET_Customer_Basket_Response.totalAmount;
			System.out.println("Total Cost is: " + totalcost);
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			ArrayList<JSONObject> array = new ArrayList<JSONObject>();
			JSONObject json = new JSONObject();

			try {
				json.put("key", "value");// your json
			} catch (JsonException e) {
				e.printStackTrace();
			}
			array.add(json);
			String printjsonarray = array.toString();// pass this into the request

			Map<String, Object> map = new LinkedHashMap<>();

			map.put("retailHubBasket", GET_Customer_Basket_Response.sbasket);
			map.put("cardPayments", Arrays.asList(new LinkedHashMap<String, Object>() {
				{
					put("cardReference", "string");
					put("issueNumber", "string");
					put("startMMYY", "string");
					put("expiryMMYY", "string");
					put("maskedPAN", "123455561234");
					put("amount", "1000");

				}
			}));

			ArrayList<String> newprinters_CCSTNewbury = new ArrayList<String>();
			newprinters_CCSTNewbury.add("CCSTNewbury");
			map.put("fulfilmentConfiguration", (new LinkedHashMap<String, Object>() {
				{
					put("availablePrinters", newprinters_CCSTNewbury);
					put("hopperType", "Internal");

				}

			}));

			String tisid = linkedHashMap.get("tisid");
			response = request.given().header("TisId", tisid).header("content-Type", linkedHashMap.get("Content-Type"))
					.with().body(map).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/transaction/process");

			ResponseBody respbody = response.getBody();
			PaymentNotMatchedWithBasketResp = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Payment Not Matched With Basket response is :" + PaymentNotMatchedWithBasketResp);

			PaymentNotMatchedWithBasketStatuscode = response.getStatusCode();
			softassert5.assertEquals(response.getStatusCode(), 3016);
			Allure.attachment("Payment Not Matched With Basket response Status",
					"Response Status as : \n" + PaymentNotMatchedWithBasketResp);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Payment Not Matched With Basket ",
					"Process Transaction couldn't run successfully and Error is as shown below: \n"
							+ PaymentNotMatchedWithBasketStatuscode);
		}

	}

	public static void paymentwithInvalidReference(LinkedHashMap<String, String> linkedHashMap)
			throws ClientProtocolException {

		try {
			totalcost = GET_Customer_Basket_Response.totalAmount;
			System.out.println("Total Cost is: " + totalcost);
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			ArrayList<JSONObject> array = new ArrayList<JSONObject>();
			JSONObject json = new JSONObject();

			try {
				json.put("key", "value");// your json
			} catch (JsonException e) {
				e.printStackTrace();
			}
			array.add(json);
			String printjsonarray = array.toString();// pass this into the request

			Map<String, Object> map = new LinkedHashMap<>();

			map.put("retailHubBasket", GET_Customer_Basket_Response.sbasket);
			map.put("cardPayments", Arrays.asList(new LinkedHashMap<String, Object>() {
				{
					put("cardRef", "string");
					put("issueNumber", "string");
					put("startMMYY", "string");
					put("expiryMMYY", "string");
					put("maskedPAN", "123455561234");
					put("amount", totalcost.toString());

				}
			}));

			ArrayList<String> newprinters_CCSTNewbury = new ArrayList<String>();
			newprinters_CCSTNewbury.add("CCSTNewbury");
			map.put("fulfilmentConfiguration", (new LinkedHashMap<String, Object>() {
				{
					put("availablePrinters", newprinters_CCSTNewbury);
					put("hopperType", "Internal");

				}

			}));

			String tisid = linkedHashMap.get("tisid");
			response = request.given().header("TisId", tisid).header("content-Type", linkedHashMap.get("Content-Type"))
					.with().body(map).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/transaction/process");

			ResponseBody respbody = response.getBody();
			PaymentwithInvalidReferenceResp = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Payment with Invalid Reference response is :" + PaymentwithInvalidReferenceResp);

			PaymentwithInvalidReferenceRespStatuscode = response.getStatusCode();
			softassert5.assertEquals(response.getStatusCode(), 3018);
			Allure.attachment("Payment with Invalid Reference response Status",
					"Response Status as : \n" + PaymentwithInvalidReferenceResp);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Payment with Invalid Reference",
					"Process Transaction couldn't run successfully and Error is as shown below: \n"
							+ PaymentwithInvalidReferenceResp);
		}

	}

	public static void pastTrip(LinkedHashMap<String, String> linkedHashMap) throws ClientProtocolException {

		try {
			totalcost = GET_Customer_Basket_Response.totalAmount;
			System.out.println("Total Cost is: " + totalcost);
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			ArrayList<JSONObject> array = new ArrayList<JSONObject>();
			JSONObject json = new JSONObject();

			try {
				json.put("key", "value");// your json
			} catch (JsonException e) {
				e.printStackTrace();
			}
			array.add(json);
			String printjsonarray = array.toString();// pass this into the request

			Map<String, Object> map = new LinkedHashMap<>();

			map.put("retailHubBasket", GET_Customer_Basket_Response.sbasket);
			map.put("cardPayments", Arrays.asList(new LinkedHashMap<String, Object>() {
				{
					put("cardReference", "string");
					put("issueNumber", "string");
					put("startMMYY", "string");
					put("expiryMMYY", "string");
					put("maskedPAN", "123455561234");
					put("amount", totalcost.toString());

				}
			}));

			ArrayList<String> newprinters_CCSTNewbury = new ArrayList<String>();
			newprinters_CCSTNewbury.add("CCSTNewbury");
			map.put("fulfilmentConfiguration", (new LinkedHashMap<String, Object>() {
				{
					put("availablePrinters", newprinters_CCSTNewbury);
					put("hopperType", "Internal");

				}

			}));

			String tisid = linkedHashMap.get("tisid");
			response = request.given().header("TisId", tisid).header("content-Type", linkedHashMap.get("Content-Type"))
					.with().body(map).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/transaction/process");

			ResponseBody respbody = response.getBody();
			PastTripResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Process Transaction response is :" + PastTripResponse);

			PastTripResponseStatuscode = response.getStatusCode();
			softassert5.assertEquals(response.getStatusCode(), 3017);
			Allure.attachment("Past Trip Response Status", "Response Status as : \n" + PastTripResponse);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Past Trip Response Status Code",
					"Process Transaction couldn't run successfully and Error is as shown below: \n"
							+ PastTripResponseStatuscode);
		}

	}

	public static void mandatoryReservation(LinkedHashMap<String, String> linkedHashMap)
			throws ClientProtocolException {

		try {
			totalcost = GET_Customer_Basket_Response.totalAmount;
			System.out.println("Total Cost is: " + totalcost);
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			ArrayList<JSONObject> array = new ArrayList<JSONObject>();
			JSONObject json = new JSONObject();

			try {
				json.put("key", "value");// your json
			} catch (JsonException e) {
				e.printStackTrace();
			}
			array.add(json);
			String printjsonarray = array.toString();// pass this into the request

			Map<String, Object> map = new LinkedHashMap<>();

			map.put("retailHubBasket", GET_Customer_Basket_Response.sbasket);
			map.put("cardPayments", Arrays.asList(new LinkedHashMap<String, Object>() {
				{
					put("cardReference", "string");
					put("issueNumber", "string");
					put("startMMYY", "string");
					put("expiryMMYY", "string");
					put("maskedPAN", "123455561234");
					put("amount", totalcost.toString());

				}
			}));

			ArrayList<String> newprinters_CCSTNewbury = new ArrayList<String>();
			newprinters_CCSTNewbury.add("CCSTNewbury");
			map.put("fulfilmentConfiguration", (new LinkedHashMap<String, Object>() {
				{
					put("availablePrinters", newprinters_CCSTNewbury);
					put("hopperType", "Internal");

				}

			}));
			String tisid = linkedHashMap.get("tisid");
			response = request.given().header("TisId", tisid).header("content-Type", linkedHashMap.get("Content-Type"))
					.with().body(map).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/transaction/process");

			ResponseBody respbody = response.getBody();
			MandatoryReservationResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Process Transaction response is :" + MandatoryReservationResponse);

			MandatoryReservationStatuscode = response.getStatusCode();
			softassert5.assertEquals(response.getStatusCode(), 3014);
			Allure.attachment("Process Transaction Run with Mandatory Reservation Record and Response Status is as ",
					"Response Status as : \n" + MandatoryReservationResponse);
		}
		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Process Transaction Run with Mandatory Reservation Record",
					"Process Transaction couldn't run successfully and Error is as shown below: \n"
							+ MandatoryReservationStatuscode);
		}

	}

}
