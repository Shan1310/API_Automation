//Auther : shantanu devkar
package Evoke.pageobject;

import java.util.LinkedHashMap;

import org.apache.http.client.ClientProtocolException;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Evoke.utilities.TestBase;
import groovyjarjarasm.asm.Type;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class POST_StartShift extends TestBase {
	public static String Tisid;
	public static String cook;
	public static String StartshiftResponse;
	public static int StartshiftResponseStatuscode;
	public static RequestSpecification req;
	public static String SourceLoc;
	public static String DestinationLoc;

	public static void startshift(LinkedHashMap<String, String> linkedHashMap) {

		try {
			SourceLoc = linkedHashMap.get("sourceLoc");
			DestinationLoc = linkedHashMap.get("desLoc");
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			String tisid = linkedHashMap.get("tisid");
//			Response response = request.given().header("TisId", tisid)
//					.header("content-Type", linkedHashMap.get("Content-Type")).with().body(postcontent).auth()
//					.preemptive().basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log()
//					.all().post("/shift/start");
//			RestAssured.proxy("165.225.121.64");
//			RestAssured.proxy("165.225.121.71", 8888);
		    Response response = request.given().header("TisId", tisid)
			.header("content-Type", linkedHashMap.get("Content-Type")).body(postcontent).log().all().post("/shift/start");

			ResponseBody respbody = response.getBody();
			StartshiftResponse = respbody.asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie" + cook);
			System.out.println("Start Shift response is :" + StartshiftResponse);

			StartshiftResponseStatuscode = response.getStatusCode();
			softassert1.assertEquals(StartshiftResponseStatuscode, 200);
			System.out.println("Start shift started successfully and the status is 200 as Expected: "
					+ StartshiftResponseStatuscode);
			Allure.addAttachment("Start Shift Started => " + SourceLoc + " To " + DestinationLoc, StartshiftResponse);
//	  Allure.attachment("Start Shift Response", "Start Shift run successfully and response is as below: \n" +StartshiftResponse);
			Allure.attachment("Start Shift Response", "Response Status as : \n" + StartshiftResponseStatuscode);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Start Shift Response",
					"Start Shift couldn't run successfully and Error is as shown below: \n" + StartshiftResponse);
		}

	}

}
