//Auther : shantanu devkar
package Evoke.pageobject;



import Evoke.utilities.TestBase;
import io.qameta.allure.Allure;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GET_Customer_Logoff extends TestBase {
	public static RequestSpecification request;
    static String sbasket;
	public static void logoff() throws Exception{
		

		CommonRequest common = new CommonRequest();
		request = common.getSpecificationRequest();

		Response resp = request.given().cookie(POST_StartShift.cook).auth().preemptive()
				.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().log().all()
				.get("/customer/logoff");
		System.out.println("Customer Logoff Successfully");
				
		}	

	}


