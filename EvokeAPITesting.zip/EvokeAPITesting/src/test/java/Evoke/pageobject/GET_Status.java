//Auther : shantanu devkar
package Evoke.pageobject;

import java.util.LinkedHashMap;

import org.testng.asserts.SoftAssert;

import Evoke.utilities.TestBase;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ResponseOptions;
import io.restassured.specification.RequestSpecification;

public class GET_Status extends TestBase {
	public static RequestSpecification request;
	public static String cook;
    public static String statusResponse;
    public static int GetResponseStatuscode;
	public static void getStatus(LinkedHashMap<String, String> linkedHashMap) throws Exception{
		
		try
		{
			
	  System.out.println(linkedHashMap); 
	  RestAssured.baseURI =prop.getProperty("EvokeBaseURL"); 
	  RequestSpecification request = RestAssured.given(); 

//	  String tisid = linkedHashMap.get("tisid");
//	  Response response = request.given().header("TisId", linkedHashMap.get( "tisid")).
//	  header("content-Type", linkedHashMap.get("Content-Type")).
//      with().auth().preemptive().basic(prop.getProperty("Username"),
//	  prop.getProperty("Password")).
//	  when().given().log().all().get("/status");
	  
	  Response response = request.given().header("TisId", linkedHashMap.get( "tisid")).
			  header("content-Type", linkedHashMap.get("Content-Type")).log().all().get("/status");
	  
	  ResponseBody respbody = response.getBody(); 
	  statusResponse = respbody.asString(); 
	  cook = response.getDetailedCookies().toString();
	  request.cookie(cook);
	  
	  System.out.println("Status" + cook);
	  System.out.println("Get Status response is :" +statusResponse);
	  
	  GetResponseStatuscode = response.getStatusCode();
	  softassert8.assertEquals(response.getStatusCode(), 200);
	  System.out.println("Get Status started successfully and the status is 200 as Expected: "+GetResponseStatuscode);
					
	  Allure.attachment("Get Status Response", "Get Status run successfully and response is as below: \n" +statusResponse);
	  Allure.attachment("Response Status", "Response Status as : \n" +GetResponseStatuscode);
		
		}
			catch(Exception e)
		{
			e.printStackTrace();
			Allure.attachment("Get Status Response", "Get Status couldn't run successfully and Error is as shown below: \n" +statusResponse );
		}

	}
		
		
	}


