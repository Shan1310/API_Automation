//Auther : shantanu devkar

package Evoke.pageobject;

import java.util.LinkedHashMap;

import Evoke.utilities.TestBase;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.specification.RequestSpecification;

public class CommonRequest extends TestBase {
	

	public RequestSpecification getSpecificationRequest()
	{
		
		RestAssured.baseURI = prop.getProperty("BaseURL");
		RequestSpecification request = RestAssured.given();
		request.header("Content-Type", "application/json");
		//request.header("clienttype", "application");
		request.header("clienttype", "browser");
		request.given().auth().preemptive().
		basic(prop.getProperty("Username"),prop.getProperty("Password"));
		return request;
	}
	
	public static Header getSpecificationRequestforStartShift()
	{
		
		RestAssured.baseURI = prop.getProperty("EvokeURL");
		RequestSpecification request = RestAssured.given();
		request.header("Content-Type", "application/json");
		request.header("Content-Length", "<calculated when request is sent>");
		request.header("Host", "<calculated when request is sent>");
		request.header("User-Agent", "PostmanRuntime/7.26.10");
		request.header("Accept", "*/*");
		request.header("Accept-Encoding", "gzip, deflate, br");
		request.header("Connection", "keep-alive");
		request.header("TisId", "2");
		request.given().auth().preemptive().
		basic(prop.getProperty("Username"),prop.getProperty("Password"));
		
		return (Header) request;
	}
}
