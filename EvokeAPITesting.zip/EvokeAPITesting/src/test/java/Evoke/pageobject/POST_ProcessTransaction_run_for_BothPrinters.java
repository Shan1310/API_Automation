//Auther : shantanu devkar
package Evoke.pageobject;

import java.awt.Checkbox;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import com.jayway.jsonpath.JsonPath;
import org.apache.http.client.ClientProtocolException;
import org.apache.poi.xslf.model.geom.IfElseExpression;
import org.json.simple.JSONObject;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.JsonException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.sun.xml.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;


import Evoke.utilities.Encryption;
import Evoke.utilities.ParseTicket;
import Evoke.utilities.TestBase;
import gherkin.deps.com.google.gson.JsonArray;
import gherkin.deps.com.google.gson.JsonObject;
import groovyjarjarasm.asm.Type;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.codec.binary.Base64;

public class POST_ProcessTransaction_run_for_BothPrinters extends TestBase {

	
	public static String Tisid;
	public static String cook;
	public static String ProcessTransactionResponse;
	public static int ProcessTransactionResponseStatuscode;
	public static String Couponlink = null;
	public BufferedImage image = null;
	public static Response response;
	public static Response respbody;
	public static String totalcost = GET_Customer_Basket_Response.totalAmount;
	public static String TicketType;
	public static String FulfilmentType = "$.transactionDetailsList[0].couponsToPrint[0].fulfilmentType";
//	x.transactionDetailsList[1].couponsToPrint[0].items[1]
	public static String word = "items";
	public static int count = 0;

	


public static void ProcessTransaction(LinkedHashMap<String, String> linkedHashMap) throws ClientProtocolException {
		try {
			totalcost = GET_Customer_Basket_Response.totalAmount;
			System.out.println("Total Cost is: " + totalcost);
			System.out.println(linkedHashMap);
			RestAssured.baseURI = prop.getProperty("EvokeBaseURL");
			RequestSpecification request = RestAssured.given();
			LinkedHashMap<String, String> postcontent = new LinkedHashMap<>();
			postcontent.put("userId", linkedHashMap.get("userid"));
			postcontent.put("isRevenue", linkedHashMap.get("isrevenue"));

			ArrayList<JSONObject> array = new ArrayList<JSONObject>();
			JSONObject json = new JSONObject();

			try {
				json.put("key", "value");// your json
			} catch (JsonException e) {
				e.printStackTrace();
			}
			array.add(json);
			String printjsonarray = array.toString();// pass this into the request

			Map<String, Object> map = new LinkedHashMap<>();

			map.put("retailHubBasket", GET_Customer_Basket_Response.sbasket);
			map.put("cardPayments", Arrays.asList(new LinkedHashMap<String, Object>() {
				{
					put("cardReference", "string");
					put("issueNumber", "string");
					put("startMMYY", "string");
					put("expiryMMYY", "string");
					put("maskedPAN", "123455561234");
					put("amount", totalcost.toString());

				}
			}));

			ArrayList<String> newprinters = new ArrayList<String>();
			newprinters.add("PaperRoll");
			newprinters.add("CCSTNewbury");
			map.put("fulfilmentConfiguration", (new LinkedHashMap<String, Object>() {
				{
					put("availablePrinters", newprinters);
					put("hopperType", "Internal");

				}

			}));

			String tisid = linkedHashMap.get("tisid");
			response = request.given().header("TisId", tisid).header("content-Type", linkedHashMap.get("Content-Type"))
					.with().body(map).auth().preemptive()
					.basic(prop.getProperty("Username"), prop.getProperty("Password")).when().given().log().all()
					.post("/transaction/process");
			
//			ResponseBody respbody = response.getBody();
			ProcessTransactionResponse = response.getBody().asString();
			cook = response.getDetailedCookies().toString();
			request.cookie(cook);

			System.out.println("Rail resp cookie " + cook);
			System.out.println("Process Transaction response is : " + ProcessTransactionResponse);

			ProcessTransactionResponseStatuscode = response.getStatusCode();
			softassert5.assertEquals(response.getStatusCode(), 200);
			System.out.println("Process Transaction done successfully and the status is 200 as Expected: "
					+ ProcessTransactionResponseStatuscode);

			Allure.attachment("Process Transaction Response",
					"ProcessTransaction run successfully and response is as below: \n" + ProcessTransactionResponse);
			Allure.attachment("Process Transaction Response Status",
					"Response Status as : \n" + ProcessTransactionResponseStatuscode);
			
		
			
			// ............................Decode Coupon Link--------------------------------------//
			
			TicketType = JsonPath.read(ProcessTransactionResponse, FulfilmentType ).toString();
			ParseTicket.ticketConverter(ProcessTransactionResponse,TicketType);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Process Transaction Response",
					"Process Transaction couldn't run successfully and Error is as shown below: \n"
							+ ProcessTransactionResponseStatuscode);
		}
}
	
}

			
			
	




	


