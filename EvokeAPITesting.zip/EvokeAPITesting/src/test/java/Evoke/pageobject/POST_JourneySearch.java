//Auther : shantanu devkar
package Evoke.pageobject;

import org.apache.http.auth.AUTH;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Evoke.utilities.TestBase;
import io.qameta.allure.Allure;
import io.restassured.config.ParamConfig;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import static org.hamcrest.Matchers.*;

import java.util.LinkedHashMap;

public class POST_JourneySearch extends TestBase {

	public static String outwardserviceid;
	public static String outwardfaregroup;
	public static String railjourneyresp;
	public static RequestSpecification request;
	public static String ReturnServiceid;
	public static String Returnfaregroup;
	public static String Oneway;
	public static String Openreturn;
	public static String FromLocation;
	public static String ToLocation;
	
	
	public static void railjourney(LinkedHashMap<String, String> linkedHashMap) {


		try {
            System.out.println(linkedHashMap);
			CommonRequest com = new CommonRequest();
			request = com.getSpecificationRequest();
//			request.cookie(POST_JourneySearch.cook);
			Response response = request.given()
					.queryParams("locfrom",linkedHashMap.get("locfrom") , "locto", linkedHashMap.get("locto"), "datetimedepart",
							linkedHashMap.get( "datetimedepart"), "outwardDepartAfter", linkedHashMap.get( "outwardDepartAfter"), 
							"timetableonly",
							linkedHashMap.get( "timetableonly"), "isSeasonTicket", linkedHashMap.get( "isSeasonTicket"), 
							"showServices",
							linkedHashMap.get( "showServices"), "oneway", linkedHashMap.get("oneway"),
							"dateTimeReturn", linkedHashMap.get( "dateTimeReturn"),"returnDepartAfter", linkedHashMap.get( "returnDepartAfter"), 
							"openreturn", linkedHashMap.get( "openreturn"),
							"monthly",
							linkedHashMap.get( "monthly"), "directServicesOnly", linkedHashMap.get( "directServicesOnly"),
							"standardclass",
							linkedHashMap.get( "standardclass"), "firstclass", linkedHashMap.get( "firstclass"), 
							"passengergroup", linkedHashMap.get( "passengergroup"),
							"enquirymethod", linkedHashMap.get( "enquirymethod"), "sleepersOnly", linkedHashMap.get( "sleepersOnly"))
					.auth().preemptive().basic(prop.getProperty("Username"), prop.getProperty("Password")).

					when().given().log().all().post("/rail/journeys");
			

			ResponseBody respbody = response.getBody();

			railjourneyresp = respbody.asString();
			POST_StartShift.cook = response.getDetailedCookies().toString();		
			request.cookie(POST_StartShift.cook);
			
			System.out.println("Rail resp cookie" + POST_StartShift.cook);
			

			System.out.println("Rail Journey response is : " + railjourneyresp);
			
			int railresponsecode = response.getStatusCode();
			softassert2.assertEquals(response.getStatusCode(), 201);
			
			Thread.sleep(2000);
			
			outwardserviceid = response.path("getrailpostresponse.services[" + linkedHashMap.get("Serviceid") + "].name");
			
			outwardfaregroup = response.path("getrailpostresponse.services[" + linkedHashMap.get("Serviceid") + "].servicefares["
					+ linkedHashMap.get("Faregroup") + "].faregroup");
			
			ReturnServiceid = response.path("getrailpostresponse.services[" + linkedHashMap.get("ReturnServiceid") + "].name");
			

			Returnfaregroup = response.path("getrailpostresponse.services[" + linkedHashMap.get("ReturnServiceid") + "].servicefares["
					+ linkedHashMap.get("Faregroup") + "].faregroup");
			
			Oneway = linkedHashMap.get("oneway");
			Openreturn = linkedHashMap.get("openreturn");
			
			FromLocation = linkedHashMap.get("locfrom");
			ToLocation = linkedHashMap.get("locto");
			
			
			System.out.println("oneway " + linkedHashMap.get("oneway"));
			
			System.out.println("ReturnServiceid " + linkedHashMap.get("ReturnServiceid"));
			System.out.println("outward Service id is " + outwardserviceid);
			System.out.println("outward fare group is " + outwardfaregroup);
			
			System.out.println("Return faregroup id " + ReturnServiceid);

			System.out.println("Return Group id " + Returnfaregroup);

			Allure.attachment("customer Rail journey response: ",
					"Customer Rail journey API response is " + railjourneyresp);
		}

		catch (Exception e) {
			e.printStackTrace();
			Allure.attachment("Rail journey response: ",
					"Rail journey call couldn't run and as a result status code is:");
		}

		

	}

	public static void getfaregroupandserviceid(LinkedHashMap<String, String> linkedHashMap) {

		String Serviceid = POST_JourneySearch.outwardserviceid;
		Allure.attachment("Selected service ", "Selected service id is =>" + Serviceid);

		String Faregroupid = POST_JourneySearch.outwardfaregroup;

		Allure.attachment("Selected Faregroup ", "Selected Faregroup id is =>" + Faregroupid);

		System.out.println("Faregroup");

	}

}
