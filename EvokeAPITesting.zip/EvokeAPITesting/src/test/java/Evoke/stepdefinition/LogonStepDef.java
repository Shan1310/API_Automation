package Evoke.stepdefinition;



import Evoke.pageobject.POST_CustomerLogon;
import Evoke.utilities.TestBase;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LogonStepDef extends TestBase {

	public static int inum;
    
	@Given("^Valid credentials with valid endpoint$")
	public void Valid_credentials_with_valid_endpoint()
	{
		String row = prop.getProperty("firstrow");
		inum = Integer.parseInt(row);
		TestBase.setData(inum);
       
		POST_CustomerLogon.logon();
	}
	
}
	

		
	

