package Evoke.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.client.ClientProtocolException;

import Evoke.pageobject.ErrorCodeVerification;
import Evoke.pageobject.GET_Configuration;
import Evoke.pageobject.GET_Customer_Basket_Response;
import Evoke.pageobject.GET_Customer_Logoff;
import Evoke.pageobject.GET_Status;
import Evoke.pageobject.POST_CustomerBasket;
import Evoke.pageobject.POST_EndShift;
import Evoke.pageobject.POST_FailTransaction;
import Evoke.pageobject.POST_JourneySearch;
import Evoke.pageobject.POST_ProcessTransaction;
import Evoke.pageobject.POST_ProcessTransaction_run_for_BothPrinters;
import Evoke.pageobject.POST_ProcessTransaction_run_for_CCSTNewbury;
import Evoke.pageobject.POST_ProcessTransaction_run_for_PaperRoll;
import Evoke.pageobject.POST_StartShift;
import Evoke.utilities.ExcelReader;
import Evoke.utilities.TestBase;

public class Latest_customerRailJourney extends TestBase {

	public static int inum;
	public static String totalcost =GET_Customer_Basket_Response.totalAmount;
	List<LinkedHashMap<String, String>> testDataMap = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			"Rail-POST");
	
	List<LinkedHashMap<String, String>> SingleTicket = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "OnewaySingleTicket");
	
	List<LinkedHashMap<String, String>> ReturnTicketTestData = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "ReturnTicket");
	
	List<LinkedHashMap<String, String>> BlankTisId = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "BlankTisID");
	
	List<LinkedHashMap<String, String>> Emptybody = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "EmptyBody");
	
	List<LinkedHashMap<String, String>> UserIdmorethanEightChar = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "UserIdToLong");
	
	List<LinkedHashMap<String, String>> AlphanumericUserID = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "AlphanumericUserId");
	
	List<LinkedHashMap<String, String>> invalidBasket = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "InvalidBasket");
	
	List<LinkedHashMap<String, String>> eticketNotfulfilled = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "E-ticketNotfulfilled");
	
	List<LinkedHashMap<String, String>> PastTripTestData = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "PastTrip");
	
	List<LinkedHashMap<String, String>> MandatoryReservationTestData = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "MandatoryReservation");
	
	List<LinkedHashMap<String, String>> ConfigurationAPI = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "Configuration_API");
	
	public static List<LinkedHashMap<String, String>> availablePrinters = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),
			  "AvailablePrinters_Tickets");
	
//*******************************************************************************************************************************************	
	
	@Given("User Run the API From Start shift To End shift with CCSTNewbury Printer and Check the Status With Running fail Transaction")
	public void user_Run_the_API_From_Start_shift_To_End_shift_with_CCSTNewbury_Printer_and_Check_the_Status_With_Running_fail_Transaction() throws Exception {
    System.out.println(testDataMap.size());
        
		for (int i = 0; i < testDataMap.size(); i++) {
			totalcost =null;
			POST_StartShift.startshift(testDataMap.get(i));
			Thread.sleep(2000);
			POST_JourneySearch.railjourney(testDataMap.get(i));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(testDataMap.get(i));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			POST_ProcessTransaction_run_for_CCSTNewbury.ProcessTransaction(testDataMap.get(i));
			Thread.sleep(4000);
			POST_FailTransaction.failTransaction(testDataMap.get(i));
			Thread.sleep(3000);
			POST_EndShift.endshift(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Status.getStatus(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Customer_Logoff.logoff();
			Thread.sleep(5000);
		}
		TestBase.CheckAssert();
	}

	@Given("User Run the API From Start shift To End shift with PaperRoll Printer and Check the Status With Running fail Transaction")
	public void user_Run_the_API_From_Start_shift_To_End_shift_with_PaperRoll_Printer_and_Check_the_Status_With_Running_fail_Transaction() throws Exception {
            System.out.println(testDataMap.size());
        
		for (int i = 1; i < testDataMap.size(); i++) {
			totalcost =null;
			POST_StartShift.startshift(testDataMap.get(i));
			Thread.sleep(2000);
			POST_JourneySearch.railjourney(testDataMap.get(i));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(testDataMap.get(i));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			POST_ProcessTransaction_run_for_PaperRoll.ProcessTransaction(testDataMap.get(i));
			Thread.sleep(4000);
			POST_FailTransaction.failTransaction(testDataMap.get(i));
			Thread.sleep(3000);
			POST_EndShift.endshift(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Status.getStatus(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Customer_Logoff.logoff();
			Thread.sleep(5000);
		}
		TestBase.CheckAssert();
	}

	@Given("User Run the API From Start shift To End shift with BothPrinters and Check the Status With Running fail Transaction")
	public void user_Run_the_API_From_Start_shift_To_End_shift_with_BothPrinters_and_Check_the_Status_With_Running_fail_Transaction() throws Exception {
            System.out.println(testDataMap.size());
		for (int i = 0; i < testDataMap.size(); i++) {
			totalcost =null;
			POST_StartShift.startshift(testDataMap.get(i));
			Thread.sleep(2000);
			POST_JourneySearch.railjourney(testDataMap.get(i));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(testDataMap.get(i));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(testDataMap.get(i));
			Thread.sleep(4000);
			POST_FailTransaction.failTransaction(testDataMap.get(i));
			Thread.sleep(3000);
			POST_EndShift.endshift(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Status.getStatus(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Customer_Logoff.logoff();
			Thread.sleep(5000);
		}
		TestBase.CheckAssert();
	}
	
	 
	@Given("User Add Multiple Tickets into Basket with CCSTNewbury Printer and then Run failTransactions and Check The Status")
	public void user_Add_Multiple_Tickets_into_Basket_with_CCSTNewbury_Printer_and_then_Run_failTransactions_and_Check_The_Status() throws Exception{
	System.out.println(testDataMap.size());
    POST_StartShift.startshift(testDataMap.get(inum));
	for (int i = 0; i < testDataMap.size(); i++) {
		totalcost =null;
		POST_JourneySearch.railjourney(testDataMap.get(i));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(testDataMap.get(i));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(testDataMap.get(i));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		GET_Customer_Logoff.logoff();
		Thread.sleep(3000);
	}
	    POST_ProcessTransaction_run_for_CCSTNewbury.ProcessTransaction(testDataMap.get(inum));
	    Thread.sleep(2000);
		POST_FailTransaction.failTransaction(testDataMap.get(inum));
		Thread.sleep(2000);
		POST_EndShift.endshift(testDataMap.get(inum));
		Thread.sleep(1000);
		GET_Status.getStatus(testDataMap.get(inum));
		Thread.sleep(1000);
		TestBase.CheckAssert();
	}

	@Given("User Add Multiple Tickets into Basket with PaperRoll Printer and then Run failTransactions and Check The Status")
	public void user_Add_Multiple_Tickets_into_Basket_with_PaperRoll_Printer_and_then_Run_failTransactions_and_Check_The_Status() throws Exception{
		System.out.println(testDataMap.size());
	    POST_StartShift.startshift(testDataMap.get(inum));
		for (int i = 1; i < testDataMap.size(); i++) {
			totalcost =null;
			POST_JourneySearch.railjourney(testDataMap.get(i));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(testDataMap.get(i));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			GET_Customer_Logoff.logoff();
			Thread.sleep(3000);
		}
		    POST_ProcessTransaction_run_for_PaperRoll.ProcessTransaction(testDataMap.get(inum));
		    Thread.sleep(2000);
			POST_FailTransaction.failTransaction(testDataMap.get(inum));
			Thread.sleep(2000);
			POST_EndShift.endshift(testDataMap.get(inum));
			Thread.sleep(1000);
			GET_Status.getStatus(testDataMap.get(inum));
			Thread.sleep(1000);
			TestBase.CheckAssert();
		}
	

	@Given("User Add Multiple Tickets into Basket with BothPrinters and then Run failTransactions and Check The Status")
	public void user_Add_Multiple_Tickets_into_Basket_with_BothPrinters_and_then_Run_failTransactions_and_Check_The_Status() throws Exception{
		System.out.println(testDataMap.size());
	    POST_StartShift.startshift(testDataMap.get(inum));
		for (int i = 0; i < testDataMap.size(); i++) {
			totalcost =null;
			POST_JourneySearch.railjourney(testDataMap.get(i));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(testDataMap.get(i));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(testDataMap.get(i));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			GET_Customer_Logoff.logoff();
			Thread.sleep(3000);
		}
		    POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(testDataMap.get(inum));
		    Thread.sleep(2000);
			POST_FailTransaction.failTransaction(testDataMap.get(inum));
			Thread.sleep(2000);
			POST_EndShift.endshift(testDataMap.get(inum));
			Thread.sleep(1000);
			GET_Status.getStatus(testDataMap.get(inum));
			Thread.sleep(1000);
			TestBase.CheckAssert();
		}
	

@Given("User Verify Status After Multiple Full Transaction with CCSTNewbury Printer and Fail Last Transaction in One Shift")
public void user_Verify_Status_After_Multiple_Full_Transaction_with_CCSTNewbury_Printer_and_Fail_Last_Transaction_in_One_Shift() throws Exception{
	System.out.println(testDataMap.size());
    POST_StartShift.startshift(testDataMap.get(inum));
	for (int i = 0; i < testDataMap.size(); i++) {
		totalcost =null;
		POST_JourneySearch.railjourney(testDataMap.get(i));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(testDataMap.get(i));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(testDataMap.get(i));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		POST_ProcessTransaction_run_for_CCSTNewbury.ProcessTransaction(testDataMap.get(inum));
	    Thread.sleep(3000);
		GET_Customer_Logoff.logoff();
		Thread.sleep(3000);
	}
	    POST_FailTransaction.failTransaction(testDataMap.get(inum));
	    Thread.sleep(2000);
	    POST_EndShift.endshift(testDataMap.get(inum));
		Thread.sleep(1000);
		GET_Status.getStatus(testDataMap.get(inum));
		Thread.sleep(1000);
		TestBase.CheckAssert();
}

@Given("User Verify Status After Multiple Full Transaction with PaperRoll Printer and Fail Last Transaction in One Shift")
public void user_Verify_Status_After_Multiple_Full_Transaction_with_PaperRoll_Printer_and_Fail_Last_Transaction_in_One_Shift() throws Exception{
	System.out.println(testDataMap.size());
    POST_StartShift.startshift(testDataMap.get(inum));
	for (int i = 1; i < testDataMap.size(); i++) {
		totalcost =null;
		POST_JourneySearch.railjourney(testDataMap.get(i));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(testDataMap.get(i));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(testDataMap.get(i));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		POST_ProcessTransaction_run_for_PaperRoll.ProcessTransaction(testDataMap.get(inum));
	    Thread.sleep(3000);
		GET_Customer_Logoff.logoff();
		Thread.sleep(3000);
	}
	    POST_FailTransaction.failTransaction(testDataMap.get(inum));
	    Thread.sleep(2000);
	    POST_EndShift.endshift(testDataMap.get(inum));
		Thread.sleep(1000);
		GET_Status.getStatus(testDataMap.get(inum));
		Thread.sleep(1000);
		TestBase.CheckAssert();
}

@Given("User Verify Status After Multiple Full Transaction with BothPrinters and Fail Last Transaction in One Shift")
public void user_Verify_Status_After_Multiple_Full_Transaction_with_BothPrinters_and_Fail_Last_Transaction_in_One_Shift() throws Exception{
	System.out.println(testDataMap.size());
    POST_StartShift.startshift(testDataMap.get(inum));
	for (int i = 0; i < testDataMap.size(); i++) {
		totalcost =null;
		POST_JourneySearch.railjourney(testDataMap.get(i));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(testDataMap.get(i));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(testDataMap.get(i));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(testDataMap.get(inum));
	    Thread.sleep(3000);
		GET_Customer_Logoff.logoff();
		Thread.sleep(3000);
	}
	    POST_FailTransaction.failTransaction(testDataMap.get(inum));
	    Thread.sleep(2000);
	    POST_EndShift.endshift(testDataMap.get(inum));
		Thread.sleep(1000);
		GET_Status.getStatus(testDataMap.get(inum));
		Thread.sleep(1000);
		TestBase.CheckAssert();
}
	

@Given("User Run Start shift To End shift with CCSTNewbury Printer and Check the Status for Single Travel Ticket")
public void user_Run_Start_shift_To_End_shift_with_CCSTNewbury_Printer_and_Check_the_Status_for_Single_Travel_Ticket() throws Exception {
	POST_StartShift.startshift(SingleTicket.get(inum));
	Thread.sleep(1000);
	POST_JourneySearch.railjourney(SingleTicket.get(inum));
	Thread.sleep(2000);
	POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
	Thread.sleep(1000);
	POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
	Thread.sleep(1000);
	GET_Customer_Basket_Response.getbasket();
	Thread.sleep(1000);
	POST_ProcessTransaction_run_for_CCSTNewbury.ProcessTransaction(SingleTicket.get(inum));
	Thread.sleep(2000);
	POST_EndShift.endshift(SingleTicket.get(inum));
	Thread.sleep(1000);
	GET_Status.getStatus(SingleTicket.get(inum));
	Thread.sleep(1000);
	TestBase.CheckAssert();
}

@Given("User Run Start shift To End shift with PaperRoll Printer and Check the Status for Single Travel Ticket")
public void user_Run_Start_shift_To_End_shift_with_PaperRoll_Printer_and_Check_the_Status_for_Single_Travel_Ticket() throws Exception {
	POST_StartShift.startshift(SingleTicket.get(inum));
	Thread.sleep(1000);
	POST_JourneySearch.railjourney(SingleTicket.get(inum));
	Thread.sleep(2000);
	POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
	Thread.sleep(1000);
	POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
	Thread.sleep(1000);
	GET_Customer_Basket_Response.getbasket();
	Thread.sleep(1000);
	POST_ProcessTransaction_run_for_PaperRoll.ProcessTransaction(SingleTicket.get(inum));
	Thread.sleep(2000);
	POST_EndShift.endshift(SingleTicket.get(inum));
	Thread.sleep(1000);
	GET_Status.getStatus(SingleTicket.get(inum));
	Thread.sleep(1000);
	TestBase.CheckAssert();
}

@Given("User Run Start shift To End shift with BothPrinters and Check the Status for Single Travel Ticket")
public void user_Run_Start_shift_To_End_shift_with_BothPrinters_and_Check_the_Status_for_Single_Travel_Ticket()throws Exception  {
	POST_StartShift.startshift(SingleTicket.get(inum));
	Thread.sleep(1000);
	POST_JourneySearch.railjourney(SingleTicket.get(inum));
	Thread.sleep(2000);
	POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
	Thread.sleep(1000);
	POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
	Thread.sleep(1000);
	GET_Customer_Basket_Response.getbasket();
	Thread.sleep(1000);
	POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(SingleTicket.get(inum));
	Thread.sleep(2000);
	POST_EndShift.endshift(SingleTicket.get(inum));
	Thread.sleep(1000);
	GET_Status.getStatus(SingleTicket.get(inum));
	Thread.sleep(1000);
	TestBase.CheckAssert();
}

@Given("User Run Start shift To End shift with CCSTNewbury Printer and Check the Status for One Outward and One Return Travel Ticket")
public void user_Run_Start_shift_To_End_shift_with_CCSTNewbury_Printer_and_Check_the_Status_for_One_Outward_and_One_Return_Travel_Ticket()  throws Exception {
	POST_StartShift.startshift(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	POST_JourneySearch.railjourney(ReturnTicketTestData.get(inum));
	Thread.sleep(2000);
	POST_JourneySearch.getfaregroupandserviceid(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	POST_CustomerBasket.sendcustomerbasket(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	GET_Customer_Basket_Response.getbasket();
	Thread.sleep(1000);
	POST_ProcessTransaction_run_for_CCSTNewbury.ProcessTransaction(ReturnTicketTestData.get(inum));
	Thread.sleep(3000);
	POST_EndShift.endshift(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	GET_Status.getStatus(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	TestBase.CheckAssert();
}

@Given("User Run Start shift To End shift with PaperRoll Printer and Check the Status for One Outward and One Return Travel Ticket")
public void user_Run_Start_shift_To_End_shift_with_PaperRoll_Printer_and_Check_the_Status_for_One_Outward_and_One_Return_Travel_Ticket()  throws Exception {
	POST_StartShift.startshift(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	POST_JourneySearch.railjourney(ReturnTicketTestData.get(inum));
	Thread.sleep(2000);
	POST_JourneySearch.getfaregroupandserviceid(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	POST_CustomerBasket.sendcustomerbasket(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	GET_Customer_Basket_Response.getbasket();
	Thread.sleep(1000);
	POST_ProcessTransaction_run_for_PaperRoll.ProcessTransaction(ReturnTicketTestData.get(inum));
	Thread.sleep(3000);
	POST_EndShift.endshift(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	GET_Status.getStatus(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	TestBase.CheckAssert();
}

@Given("User Run Start shift To End shift with BothPrinters and Check the Status for One Outward and One Return Travel Ticket")
public void user_Run_Start_shift_To_End_shift_with_BothPrinters_and_Check_the_Status_for_One_Outward_and_One_Return_Travel_Ticket() throws Exception  {
	POST_StartShift.startshift(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	POST_JourneySearch.railjourney(ReturnTicketTestData.get(inum));
	Thread.sleep(2000);
	POST_JourneySearch.getfaregroupandserviceid(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	POST_CustomerBasket.sendcustomerbasket(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	GET_Customer_Basket_Response.getbasket();
	Thread.sleep(1000);
	POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(ReturnTicketTestData.get(inum));
	Thread.sleep(3000);
	POST_EndShift.endshift(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	GET_Status.getStatus(ReturnTicketTestData.get(inum));
	Thread.sleep(1000);
	TestBase.CheckAssert();
}

	
//*******************************************************Error Code Validation**************************************************************
	@Given("User Run Fail transaction before process transaction and validate the error code")
	public void user_Run_Fail_transaction_before_process_transaction_and_validate_the_error_code() throws Exception {
		POST_StartShift.startshift(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(SingleTicket.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		POST_FailTransaction.failTransaction(SingleTicket.get(inum));
		Thread.sleep(2000);
		POST_ProcessTransaction_run_for_CCSTNewbury.ProcessTransaction(SingleTicket.get(inum));
		Thread.sleep(2000);
		POST_EndShift.endshift(SingleTicket.get(inum));
		Thread.sleep(1000);
		GET_Status.getStatus(SingleTicket.get(inum));
		Thread.sleep(1000);
//		POST_ProcessTransaction_run_for_PaperRoll.ProcessTransaction(SingleTicket.get(inum));
//		Thread.sleep(2000);
//		POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(SingleTicket.get(inum));
//		Thread.sleep(3000);
		TestBase.CheckAssert();
	}
	

@Given("User Run End shift and then Call Journey search without Starting Start Shift and verify Status")
public void user_Run_End_shift_and_then_Call_Journey_search_without_Starting_Start_Shift_and_verify_Status() throws Exception {
	POST_StartShift.startshift(testDataMap.get(inum));
	Thread.sleep(1000);
	POST_EndShift.endshift(testDataMap.get(inum));
	Thread.sleep(1000);
	POST_JourneySearch.railjourney(testDataMap.get(inum));
	Thread.sleep(2000);
	GET_Status.getStatus(testDataMap.get(inum));
	Thread.sleep(1000);
	TestBase.CheckAssert();
	
}

@Given("User Run End shift call then Check the Status and again Run End shift and verify Error Code")
public void user_Run_End_shift_call_then_Check_the_Status_and_again_Run_End_shift_and_verify_Error_Code() throws Exception {
	POST_StartShift.startshift(testDataMap.get(inum));
	Thread.sleep(1000);
	POST_EndShift.endshift(testDataMap.get(inum));
	Thread.sleep(1000);
	GET_Status.getStatus(testDataMap.get(inum));
	Thread.sleep(1000);
	POST_EndShift.endshift(testDataMap.get(inum));
	Thread.sleep(1000);
	GET_Status.getStatus(testDataMap.get(inum));
	Thread.sleep(1000);
	TestBase.CheckAssert();
}

@Given("User Run the start Shift Call and Check the Status as soon as Run End Shift call and Check the Status")
public void user_Run_the_start_Shift_Call_and_Check_the_Status_as_soon_as_Run_End_Shift_call_and_Check_the_Status() throws Exception {
	 POST_StartShift.startshift(SingleTicket.get(inum));
	 Thread.sleep(1000);
	 GET_Status.getStatus(SingleTicket.get(inum));
	 Thread.sleep(1000);
	 POST_EndShift.endshift(SingleTicket.get(inum));
	 Thread.sleep(1000);
	 GET_Status.getStatus(SingleTicket.get(inum));
	 Thread.sleep(1000);
	 TestBase.CheckAssert();
	 
}



	@Given("User Run Start shift call with Keeping Tis Id Blank and verify Error Code")
	public void user_Run_Start_shift_call_with_Keeping_Tis_Id_Blank_and_verify_Error_Code() throws InterruptedException {
		ErrorCodeVerification.blankTiSId(BlankTisId.get(inum));
		Thread.sleep(1000);
	}
	
	@Given("User Run End Shift call Twice and verify Error Code")
	public void user_Run_End_Shift_call_Twice_and_verify_Error_Code() throws ClientProtocolException, InterruptedException {
		POST_StartShift.startshift(testDataMap.get(inum));
		Thread.sleep(1000);
		POST_EndShift.endshift(testDataMap.get(inum));
		Thread.sleep(1000);
		POST_EndShift.endshift(testDataMap.get(inum));
		Thread.sleep(1000);
		
	}
	
	@Given("User Enter User ID with more than Eight characters and Run Start API Call and Verify Error Code")
	public void user_Enter_User_ID_with_more_than_Eight_characters_and_Run_Start_API_Call_and_Verify_Error_Code() throws InterruptedException {
		POST_StartShift.startshift(UserIdmorethanEightChar.get(inum));
		Thread.sleep(1000);
		
		
	}
	
	@Given("User Run Start shift call with Alphanumeric User Id and verify Error Code")
	public void user_Run_Start_shift_call_with_Alphanumeric_User_Id_and_verify_Error_Code() throws InterruptedException {
		POST_StartShift.startshift(AlphanumericUserID.get(inum));
		Thread.sleep(1000);
		
		
	}
	
	@Given("User Select a fare which cannot be fulfilled by E-ticket and Run Process Transaction API and verify Error Code")
	public void user_Select_a_fare_which_cannot_be_fulfilled_by_E_ticket_and_Run_Process_Transaction_API_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(eticketNotfulfilled.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(eticketNotfulfilled.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(eticketNotfulfilled.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(eticketNotfulfilled.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		POST_ProcessTransaction.ProcessTransaction(eticketNotfulfilled.get(inum));
		Thread.sleep(2000);
		
	}

	@Given("User Run the Fail Process Transaction Call without Start Shift and verify Error Code")
	public void user_Run_the_Fail_Process_Transaction_Call_without_Start_Shift_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(testDataMap.get(inum));
		Thread.sleep(1000);
		POST_EndShift.endshift(testDataMap.get(inum));
		Thread.sleep(1000);
		POST_FailTransaction.failTransaction(testDataMap.get(inum));
		Thread.sleep(2000);
		
		
	}
	
	@Given("User Run the Start Shift API Call keeping empty Body and verify Error Code")
	public void user_Run_the_Start_Shift_API_Call_keeping_empty_Body_and_verify_Error_Code() throws InterruptedException {
		ErrorCodeVerification.emptyBody(Emptybody.get(inum));
		Thread.sleep(1000);
		
	}
	
	@Given("User Run Transaction API Call With Invalid Basket and verify Error Code and verify Error Code")
	public void user_Run_Transaction_API_Call_With_Invalid_Basket_and_verify_Error_Code_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(eticketNotfulfilled.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(eticketNotfulfilled.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(eticketNotfulfilled.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(eticketNotfulfilled.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		ErrorCodeVerification.invalidBasketResponse(eticketNotfulfilled.get(inum));
		Thread.sleep(1000);
		
	}
	
	@Given("User Run End Shift and then Run Process Transaction API and verify Error Code")
	public void user_Run_End_Shift_and_then_Run_Process_Transaction_API_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_EndShift.endshift(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(SingleTicket.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		ErrorCodeVerification.processTransactionwithoutStartShift(SingleTicket.get(inum));
		Thread.sleep(2000);
		
	}

	
	@Given("User Run the Process Transaction Call with Invalid Masked PAN and verify Error Code")
	public void user_Run_the_Process_Transaction_Call_with_Invalid_Masked_PAN_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(SingleTicket.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		ErrorCodeVerification.InvalidMaskPAN(SingleTicket.get(inum));
		Thread.sleep(1000);
		
	}
	
	@Given("User Run the Process Transaction Call without Payment Details and verify Error Code")
	public void user_Run_the_Process_Transaction_Call_without_Payment_Details_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(SingleTicket.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		ErrorCodeVerification.processTransactionwithoutPaymentDetails(SingleTicket.get(inum));
		Thread.sleep(2000);
		
	}
	
	@Given("User Run the Process Transaction Call when Payment Total Does not Match Basket Total and verify Error Code")
	public void user_Run_the_Process_Transaction_Call_when_Payment_Total_Does_not_Match_Basket_Total_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(SingleTicket.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		ErrorCodeVerification.paymentNotMatchedWithBasket(SingleTicket.get(inum));
		Thread.sleep(1000);
		
	}
	
	@Given("User Run the Process Transaction Call with Invalid Reference and verify Error Code")
	public void user_Run_the_Process_Transaction_Call_with_Invalid_Reference_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(SingleTicket.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		ErrorCodeVerification.paymentwithInvalidReference(SingleTicket.get(inum));
		Thread.sleep(1000);
		
	}
	
	@Given("User Run the Process Transaction Call with Past Trip and verify Error Code")
	public void user_Run_the_Process_Transaction_Call_with_Past_Trip_and_verify_Error_Code() throws Exception {
		
		POST_StartShift.startshift(PastTripTestData.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(PastTripTestData.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(PastTripTestData.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(PastTripTestData.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		ErrorCodeVerification.pastTrip(PastTripTestData.get(inum));
		Thread.sleep(1000);
	}
	
	@Given("User Run the Fail Process Transaction Call when No Transaction Found and verify Error Code")
	public void user_Run_the_Fail_Process_Transaction_Call_when_No_Transaction_Found_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(SingleTicket.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		POST_FailTransaction.failTransaction(SingleTicket.get(inum));
		Thread.sleep(2000);
		
	}
	
	@Given("User Select a Fare which has Mandatory reservation and Run Process Transaction API and verify Error Code")
	public void user_Select_a_Fare_which_has_Mandatory_reservation_and_Run_Process_Transaction_API_and_verify_Error_Code() throws Exception {
		POST_StartShift.startshift(MandatoryReservationTestData.get(inum));
		Thread.sleep(1000);
		POST_JourneySearch.railjourney(MandatoryReservationTestData.get(inum));
		Thread.sleep(2000);
		POST_JourneySearch.getfaregroupandserviceid(MandatoryReservationTestData.get(inum));
		Thread.sleep(1000);
		POST_CustomerBasket.sendcustomerbasket(MandatoryReservationTestData.get(inum));
		Thread.sleep(1000);
		GET_Customer_Basket_Response.getbasket();
		Thread.sleep(1000);
		ErrorCodeVerification.mandatoryReservation(MandatoryReservationTestData.get(inum));
		Thread.sleep(1000);
	}

	//***********************************************New Configuration API*******************************************************************
	
	@Given("User Run Configuration API call and check the Asset Details")
	public void user_Run_Configuration_API_call_and_check_the_Asset_Details() throws Exception {
		POST_EndShift.endshift(ConfigurationAPI.get(inum));
		Thread.sleep(2000);
		POST_StartShift.startshift(ConfigurationAPI.get(inum));
		Thread.sleep(4000);
		GET_Configuration.getConfigurationResponse(ConfigurationAPI.get(inum));
	}

	@When("User Change the asset details and ticket types From console")
	public void user_Change_the_asset_details_and_ticket_types_From_console() {
		GET_Configuration.user_Change_the_asset_details_and_ticket_types_From_console();
	}

	@Then("Verify The changes should reflect and should be shown correctly")
	public void verify_The_changes_should_reflect_and_should_be_shown_correctly() throws Exception {
		Thread.sleep(720000);
		POST_EndShift.endshift(ConfigurationAPI.get(inum));
		Thread.sleep(2000);
		POST_StartShift.startshift(ConfigurationAPI.get(inum));
		Thread.sleep(2000);
		GET_Configuration.verify_The_changes_should_reflect_and_should_be_shown_correctly(ConfigurationAPI.get(inum));
	}

	@When("Remove the added ticket types and run the endpoint URL")
	public void remove_the_added_ticket_types_and_run_the_endpoint_URL() throws Exception {
		GET_Configuration.remove_the_added_ticket_types_and_run_the_endpoint_URL();
	}

	@Then("Verify the Removed ticket types changes Reflected into Console")
	public void verify_the_Removed_ticket_types_changes_Reflected_into_Console() throws Exception {
		Thread.sleep(720000);
		POST_EndShift.endshift(ConfigurationAPI.get(inum));
		Thread.sleep(2000);
		POST_StartShift.startshift(ConfigurationAPI.get(inum));
		Thread.sleep(2000);
		GET_Configuration.verify_the_Removed_ticket_types_changes_Reflected_into_Console(ConfigurationAPI.get(inum));
	}

	
//****************************************************CCSTNewbury, PaperRoll & Both Printers***********************************************************
	
	 @Given("Run Process Transaction for Both Printers and Check the Response")
	 public void run_Process_Transaction_for_Both_Printers_and_Check_the_Response() throws Exception {
//		    POST_EndShift.endshift(availablePrinters.get(inum));
			Thread.sleep(1000);
		    System.out.println(availablePrinters.size());
		    for (int i = 1; i < availablePrinters.size(); i++) {
			totalcost =null;
		    POST_StartShift.startshift(availablePrinters.get(i));
		    Thread.sleep(1000);
		    POST_JourneySearch.railjourney(availablePrinters.get(i));
			Thread.sleep(3000);
			POST_JourneySearch.getfaregroupandserviceid(availablePrinters.get(i));
			Thread.sleep(2000);
			POST_CustomerBasket.sendcustomerbasket(availablePrinters.get(i));
			Thread.sleep(2000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(2000);
		    POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(availablePrinters.get(i));
		    Thread.sleep(4000);
		    POST_EndShift.endshift(availablePrinters.get(i));
		    }  
	 }
	 
	 @Then("Run Process Transaction for CCSTNewbury Printer and Check the Response")
	 public void run_Process_Transaction_for_CCSTNewbury_Printer_and_Check_the_Response() throws Exception {
		    System.out.println(availablePrinters.size());
		    for (int i = 1; i < availablePrinters.size(); i++) {
			totalcost =null;
		    POST_StartShift.startshift(availablePrinters.get(i));
		    Thread.sleep(1000);
		    POST_JourneySearch.railjourney(availablePrinters.get(i));
			Thread.sleep(3000);
			POST_JourneySearch.getfaregroupandserviceid(availablePrinters.get(i));
			Thread.sleep(2000);
			POST_CustomerBasket.sendcustomerbasket(availablePrinters.get(i));
			Thread.sleep(2000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(2000);
		    POST_ProcessTransaction_run_for_CCSTNewbury.ProcessTransaction(availablePrinters.get(i));
		    Thread.sleep(4000);
		    POST_EndShift.endshift(availablePrinters.get(i));
		    }
	 }
	 
	 @Then("Run Process Transaction for PaperRoll Printer and Check the Response")
	 public void run_Process_Transaction_for_PaperRoll_Printer_and_Check_the_Response() throws Exception {
		    System.out.println(availablePrinters.size());
		    for (int i = 1; i < availablePrinters.size(); i++) {
			totalcost =null;
		    POST_StartShift.startshift(availablePrinters.get(i));
		    Thread.sleep(1000);
		    POST_JourneySearch.railjourney(availablePrinters.get(i));
			Thread.sleep(3000);
			POST_JourneySearch.getfaregroupandserviceid(availablePrinters.get(i));
			Thread.sleep(2000);
			POST_CustomerBasket.sendcustomerbasket(availablePrinters.get(i));
			Thread.sleep(2000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(2000);
		    POST_ProcessTransaction_run_for_PaperRoll.ProcessTransaction(availablePrinters.get(i));
		    Thread.sleep(4000);
		    POST_EndShift.endshift(availablePrinters.get(i));
		    }
	 }  
//*********************************************************Added Multiple Ticket into Basket**********************************************************************
	 @Given("Run Process Transaction for Both Printers with Multiple Tickets which is added into Basket and Check the Response")
	 public void run_Process_Transaction_for_Both_Printers_with_Multiple_Tickets_which_is_added_into_Basket_and_Check_the_Response() throws Exception {
		    POST_StartShift.startshift(availablePrinters.get(inum));
		    System.out.println(availablePrinters.size());
		    for (int i = 0; i < availablePrinters.size(); i++) {
			totalcost =null;
		    POST_JourneySearch.railjourney(availablePrinters.get(i));
			Thread.sleep(3000);
			POST_JourneySearch.getfaregroupandserviceid(availablePrinters.get(i));
			Thread.sleep(2000);
			POST_CustomerBasket.sendcustomerbasket(availablePrinters.get(i));
			Thread.sleep(2000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
		    GET_Customer_Logoff.logoff();
			Thread.sleep(3000);
		    }

		    POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(availablePrinters.get(inum));
		    Thread.sleep(4000);
		    POST_EndShift.endshift(availablePrinters.get(inum));
			Thread.sleep(1000);
		    
	 }
	 
	 @Then("Run Process Transaction for CCSTNewbury Printer with Multiple Tickets which is added into Basket and Check the Response")
	 public void run_Process_Transaction_for_CCSTNewbury_Printer_with_Multiple_Tickets_which_is_added_into_Basket_and_Check_the_Response() throws Exception {
		    POST_StartShift.startshift(availablePrinters.get(inum));
		    System.out.println(availablePrinters.size());
		    for (int i = 0; i < availablePrinters.size(); i++) {
			totalcost =null;
		    POST_JourneySearch.railjourney(availablePrinters.get(i));
			Thread.sleep(3000);
			POST_JourneySearch.getfaregroupandserviceid(availablePrinters.get(i));
			Thread.sleep(2000);
			POST_CustomerBasket.sendcustomerbasket(availablePrinters.get(i));
			Thread.sleep(2000);  		
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
//		    GET_Customer_Logoff.logoff();
//			Thread.sleep(3000);
		    }

		    POST_ProcessTransaction_run_for_CCSTNewbury.ProcessTransaction(availablePrinters.get(inum));
		    Thread.sleep(4000);
		    POST_EndShift.endshift(availablePrinters.get(inum));
			Thread.sleep(1000);
		    
	 }
	 
	 @Then("Run Process Transaction for PaperRoll Printer with Multiple Tickets which is added into Basket and Check the Response")
	 public void run_Process_Transaction_for_PaperRoll_Printer_with_Multiple_Tickets_which_is_added_into_Basket_and_Check_the_Response() throws Exception {
		    POST_StartShift.startshift(availablePrinters.get(inum));
		    System.out.println(availablePrinters.size());
		    for (int i = 1; i < availablePrinters.size(); i++) {
			totalcost =null;
		    POST_JourneySearch.railjourney(availablePrinters.get(i));
			Thread.sleep(3000);
			POST_JourneySearch.getfaregroupandserviceid(availablePrinters.get(i));
			Thread.sleep(2000);
			POST_CustomerBasket.sendcustomerbasket(availablePrinters.get(i));
			Thread.sleep(2000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
		    GET_Customer_Logoff.logoff();
			Thread.sleep(3000);
		    }

		    POST_ProcessTransaction_run_for_PaperRoll.ProcessTransaction(availablePrinters.get(inum));
		    Thread.sleep(4000);
		    POST_EndShift.endshift(availablePrinters.get(inum));
			Thread.sleep(1000);
		    
	 }
	//*********************************************************New Error code added for validation**********************************************************************
	 @Given("User run start shift to process transaction for past trip and check the error code")
	 public void user_run_start_shift_to_process_transaction_for_past_trip_and_check_the_error_code() throws Exception {
	   
			POST_StartShift.startshift(PastTripTestData.get(inum));
			Thread.sleep(1000);
			POST_JourneySearch.railjourney(PastTripTestData.get(inum));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(PastTripTestData.get(inum));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(PastTripTestData.get(inum));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			ErrorCodeVerification.pastTrip(PastTripTestData.get(inum));
			Thread.sleep(1000);
	     
	 }

	 @Given("User Run Process Transaction Call without Payment details and check error code")
	 public void user_Run_Process_Transaction_Call_without_Payment_details_and_check_error_code() throws Exception {
			POST_StartShift.startshift(SingleTicket.get(inum));
			Thread.sleep(1000);
			POST_JourneySearch.railjourney(SingleTicket.get(inum));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			ErrorCodeVerification.processTransactionwithoutPaymentDetails(SingleTicket.get(inum));
			Thread.sleep(2000);
	 }

	 @Given("User Select Fare which has Mandatory reservation and Run Process Transaction API to verify Error Code")
	 public void user_Select_Fare_which_has_Mandatory_reservation_and_Run_Process_Transaction_API_to_verify_Error_Code()throws Exception {
			POST_StartShift.startshift(MandatoryReservationTestData.get(inum));
			Thread.sleep(1000);
			POST_JourneySearch.railjourney(MandatoryReservationTestData.get(inum));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(MandatoryReservationTestData.get(inum));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(MandatoryReservationTestData.get(inum));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			ErrorCodeVerification.mandatoryReservation(MandatoryReservationTestData.get(inum));
			Thread.sleep(1000);
		}
	 
	 @Given("User Select the fare which cannot be fulfilled by E-ticket and Run Process Transaction API to verify Error Code")
	 public void user_Select_the_fare_which_cannot_be_fulfilled_by_E_ticket_and_Run_Process_Transaction_API_to_verify_Error_Code() throws Exception {
			POST_StartShift.startshift(eticketNotfulfilled.get(inum));
			Thread.sleep(1000);
			POST_JourneySearch.railjourney(eticketNotfulfilled.get(inum));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(eticketNotfulfilled.get(inum));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(eticketNotfulfilled.get(inum));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			POST_ProcessTransaction_run_for_PaperRoll.ProcessTransaction(eticketNotfulfilled.get(inum));
			//POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(eticketNotfulfilled.get(inum));
			Thread.sleep(2000);
			
		}
	 @Given("User Run Process Transaction and Fail the transaction twice to verify Error Code")
	 public void user_Run_Process_Transaction_and_Fail_the_transaction_twice_to_verify_Error_Code() throws Exception {
			POST_StartShift.startshift(SingleTicket.get(inum));
			Thread.sleep(1000);
			POST_JourneySearch.railjourney(SingleTicket.get(inum));
			Thread.sleep(2000);
			POST_JourneySearch.getfaregroupandserviceid(SingleTicket.get(inum));
			Thread.sleep(1000);
			POST_CustomerBasket.sendcustomerbasket(SingleTicket.get(inum));
			Thread.sleep(1000);
			GET_Customer_Basket_Response.getbasket();
			Thread.sleep(1000);
			POST_ProcessTransaction_run_for_BothPrinters.ProcessTransaction(SingleTicket.get(inum));
			Thread.sleep(1000);
			POST_FailTransaction.failTransaction(SingleTicket.get(inum));
			Thread.sleep(2000);
			POST_FailTransaction.failTransaction(SingleTicket.get(inum));
			Thread.sleep(2000);
	 }
	 
	//***********************************************Separate out the configuration API*******************************************************************
	 
	 @Given("User Run Configuration API call for Asset details and verify the Asset details")
	 public void user_Run_Configuration_API_call_for_Asset_details_and_verify_the_Asset_details()throws Exception {
		    System.out.println(ConfigurationAPI.size());
		    for (int i = 0; i < ConfigurationAPI.size(); i++) {
			POST_EndShift.endshift(ConfigurationAPI.get(i));
			Thread.sleep(2000);
			POST_StartShift.startshift(ConfigurationAPI.get(i));
			Thread.sleep(4000);
			GET_Configuration.getConfigurationResponseForAssetDetails(ConfigurationAPI.get(i));
		    }
	 }

	 @Given("User Run Configuration API call for Organisation details and verify the Organisation details")
	 public void user_Run_Configuration_API_call_for_Organisation_details_and_verify_the_Organisation_details() throws Exception  {
		    System.out.println(ConfigurationAPI.size());
		    for (int i = 0; i < ConfigurationAPI.size(); i++) {
			POST_EndShift.endshift(ConfigurationAPI.get(i));
			Thread.sleep(2000);
			POST_StartShift.startshift(ConfigurationAPI.get(i));
			Thread.sleep(4000);
			GET_Configuration.getConfigurationResponseForOrganisationDetails(ConfigurationAPI.get(i));
		    }
	 }

	 @Given("User Run Configuration API call for Popular ticket types details and verify the Popular ticket types details")
	 public void user_Run_Configuration_API_call_for_Popular_ticket_types_details_and_verify_the_Popular_ticket_types_details() throws Exception {
		    System.out.println(ConfigurationAPI.size());
		    for (int i = 0; i < ConfigurationAPI.size(); i++) {
			POST_EndShift.endshift(ConfigurationAPI.get(i));
			Thread.sleep(2000);
			POST_StartShift.startshift(ConfigurationAPI.get(i));
			Thread.sleep(4000);
			GET_Configuration.getConfigurationResponseForPopularTicketTypes(ConfigurationAPI.get(i));
		    }

	 }

	 @Given("User Run Configuration API call for Popular locations details and verify the Popular locations details")
	 public void user_Run_Configuration_API_call_for_Popular_locations_details_and_verify_the_Popular_locations_details() throws Exception {
		    System.out.println(ConfigurationAPI.size());
		    for (int i = 0; i < ConfigurationAPI.size(); i++) {
			POST_EndShift.endshift(ConfigurationAPI.get(i));
			Thread.sleep(2000);
			POST_StartShift.startshift(ConfigurationAPI.get(i));
			Thread.sleep(4000);
			GET_Configuration.getConfigurationResponseForPopularLocationsDetails(ConfigurationAPI.get(i));
		    }
	 }

	 @Given("User Run Configuration API call for Popular Railcards details and verify the Popular Railcards details")
	 public void user_Run_Configuration_API_call_for_Popular_Railcards_details_and_verify_the_Popular_Railcards_details() throws Exception {
		 	    System.out.println(ConfigurationAPI.size());
			    for (int i = 0; i < ConfigurationAPI.size(); i++) {
				POST_EndShift.endshift(ConfigurationAPI.get(i));
				Thread.sleep(2000);
				POST_StartShift.startshift(ConfigurationAPI.get(i));
				Thread.sleep(4000);
				GET_Configuration.getConfigurationResponseForPopularRailcards(ConfigurationAPI.get(i));
			    }
	 }

	 @Given("User Run Configuration API call for Excluded ticket types details and verify the Excluded ticket types details")
	 public void user_Run_Configuration_API_call_for_Excluded_ticket_types_details_and_verify_the_Excluded_ticket_types_details() throws Exception {
	 	    System.out.println(ConfigurationAPI.size());
		    for (int i = 0; i < ConfigurationAPI.size(); i++) {
			POST_EndShift.endshift(ConfigurationAPI.get(i));
			Thread.sleep(2000);
			POST_StartShift.startshift(ConfigurationAPI.get(i));
			Thread.sleep(4000);
			GET_Configuration.getConfigurationResponseForExcludedTicketTypes(ConfigurationAPI.get(i));
		    }
	 }

	 @Given("User Run Configuration API call for Excluded routes details and verify the Excluded routes details")
	 public void user_Run_Configuration_API_call_for_Excluded_routes_details_and_verify_the_Excluded_routes_details() throws Exception {
	 	    System.out.println(ConfigurationAPI.size());
		    for (int i = 0; i < ConfigurationAPI.size(); i++) {
			POST_EndShift.endshift(ConfigurationAPI.get(i));
			Thread.sleep(2000);
			POST_StartShift.startshift(ConfigurationAPI.get(i));
			Thread.sleep(4000);
			GET_Configuration.getConfigurationResponseForExcludedRoutes(ConfigurationAPI.get(i));
		    }
	 }
}
	 


