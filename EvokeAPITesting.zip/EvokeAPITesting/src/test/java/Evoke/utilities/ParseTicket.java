package Evoke.utilities;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.jayway.jsonpath.JsonPath;

import Evoke.pageobject.POST_ProcessTransaction_run_for_BothPrinters;
import io.qameta.allure.Allure;
import io.restassured.response.Response;

public class ParseTicket extends POST_ProcessTransaction_run_for_BothPrinters {
	
	public static byte[] imageByte;
	
	public static void ticketConverter(String responseProcessTransaction, String fulfilmentType) {
		
	
	JSONParser jsonParser = new JSONParser( );
	
	//Parsing the contents of the JSON file
	JSONObject inputJSONObject = new JSONObject(responseProcessTransaction);
	JSONArray jsonarray= (JSONArray) inputJSONObject.get("transactionDetailsList");
	System.out.println("Transaction Details List Array Size = " + jsonarray.length());
	
	
	for(int i=0; i<jsonarray.length(); i++)
	{
	JSONObject coupons = (JSONObject) jsonarray.get(i);
	
	//get couponToPrint array
	JSONArray CouponsArray = (JSONArray) coupons.get("couponsToPrint");
	for(int j=0; j<CouponsArray.length();j++)
	{
	JSONObject items = (JSONObject) CouponsArray.get(j);
	
	//get item of couponToPrint  array
	JSONArray itemsArray = (JSONArray) items.get("items");
	System.out.println("COUPON INDEX= "+ j);
	System.out.println("SIZE OF ITEMS ARRAY = "+ itemsArray.length());
	
	for(int k=0; k<itemsArray.length(); k++) {

	System.out.println("ITEM VALUE AT Index " +k+ " is: "+ itemsArray.get(k));

	String itemValue = itemsArray.get(k).toString();
	
	System.out.println("Ticket Type is : " +fulfilmentType);
	
	//Conversion of ticket based on the ticket type
	if(fulfilmentType.equals("CCSTNewbury")) {
	String ticketAtIndexone=itemsArray.get(1).toString();
	Allure.addAttachment("Ticket for " +fulfilmentType, Encryption.decodeKey(ticketAtIndexone));
	
	} else if(fulfilmentType.equals("ETicket")) {
		imageByte = Base64.decodeBase64(itemValue);
		Allure.addAttachment("Eticket generated in .PNG format",
				(new ByteArrayInputStream(imageByte)));

	}
//	
//	//Conversion of ticket based on the ticket type
//		if(fulfilmentType.equals("CCSTNewbury")) {
//			String Coupon1 = JsonPath.read(ProcessTransactionResponse, "$.transactionDetailsList[0].couponsToPrint[0].items[1]").toString();
//			String Coupon2 = JsonPath.read(ProcessTransactionResponse, "$.transactionDetailsList[1].couponsToPrint[0].items[1]").toString();
//			String Transaction_No1 = JsonPath.read(ProcessTransactionResponse, "$.transactionDetailsList[0].transactionNumber").toString();
//			String Transaction_No2 = JsonPath.read(ProcessTransactionResponse, "$.transactionDetailsList[0].transactionNumber").toString();
//			Allure.addAttachment("CCSTNewbury Ticket Printed", Encryption.decodeKey(Coupon1));
//			Allure.addAttachment("First Transaction No is : ", Transaction_No1);
//			Allure.addAttachment("CCSTNewbury Ticket Printed", Encryption.decodeKey(Coupon2));
//			Allure.addAttachment("Second Transaction No is : ", Transaction_No2);
//		
//		} else if(fulfilmentType.equals("ETicket")) {
//			imageByte = Base64.decodeBase64(itemValue);
//			Allure.addAttachment("Eticket generated in .PNG format",
//					(new ByteArrayInputStream(imageByte)));
//
//		}
	
	}

	}

	}
	}
}