package Evoke.utilities;

import java.util.List;
import org.apache.commons.configuration2.XMLConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;


public class ConfigreaderUtils {
	public static final Logger LOGGER;
	static Configurations configs;
	public static XMLConfiguration config;

	static {
		LOGGER = (Logger) LogManager.getLogger(ConfigreaderUtils.class);
		configs = new Configurations();
		try {
			config = configs.xml(ConfigreaderUtils.class.getResource("/Evoke/configuration/config.Properties"));
		} catch (ConfigurationException e) {
			System.out.println("Properties file not getting read as resource");
			e.printStackTrace();
			
		}
	}
	
	public static String getConfig(String configXpath) {

		String configValue = null;
		//configValue = config.getString(configXpath);
		System.out.println(configXpath);
		System.out.println(config.getString(configXpath));
		configValue = config.getString(configXpath, null);
		System.out.println("Value 1 : "+configValue);
		return configValue;
	}

	public static List<String> readConfigList(String configXpath) {

		List<String> configValues = config.getList(String.class, configXpath);
		return configValues;
	}
}
