package Evoke.utilities;

import org.apache.commons.codec.binary.Base64;

public class Encryption {
	
	static String key="";
	static byte[] encodedKey;
	
/*  To generate encoded key */ 	
//	public static void main(String args[])
//	{
//		encodeKey(key);
//		
//	}
	
	public static void encodeKey(String key)
	{
		
		encodedKey = Base64.encodeBase64(key.getBytes());
		System.out.println("Encoded key: "+ new String(encodedKey));
	}
	
	public static String decodeKey(String keyToDecode)
	{
		byte[] decodedKey = Base64.decodeBase64(keyToDecode);		
		return (new String(decodedKey));
	}
	
	

}
