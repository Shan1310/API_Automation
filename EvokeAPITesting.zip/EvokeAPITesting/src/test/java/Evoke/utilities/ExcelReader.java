package Evoke.utilities;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader extends TestBase{
	
	public static Sheet sheet;

	
	public static List<LinkedHashMap<String,String>> excelReadHashMap(String sExcelPath, String sSheetName) {

		String[] sHeaderKey = new String[0];
		String[] sValue = new String[0];
		LinkedHashMap<String, String> RowData;
		List<LinkedHashMap<String,String>> DataList = new ArrayList<>();
		try 
		{
			FileInputStream oFis = new FileInputStream(sExcelPath);
			Workbook workbook = null;
			
			if (sExcelPath.contains(".xlsx"))
			{
				workbook = new XSSFWorkbook(oFis);
				
			}
			else
			{
				workbook  = new HSSFWorkbook(oFis);
			}
		     sheet = workbook.getSheet(sSheetName);
		     Iterator<Row> rowIterator =null;
		     rowIterator = sheet.iterator();
					
			DataFormatter formatter = new DataFormatter();
			while (rowIterator.hasNext()) {
				Boolean bHeaderRow = false;
				sValue = new String[0];
				Row row = rowIterator.next();
				if (row.getRowNum() == 0) {
					bHeaderRow = true;
				}

				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					if (bHeaderRow && (cell.getCellType() != Cell.CELL_TYPE_BLANK)) {
						sHeaderKey = Arrays.copyOf(sHeaderKey, sHeaderKey.length + 1);
						sHeaderKey[cell.getColumnIndex()] = formatter.formatCellValue(cell);
					} else if ((!bHeaderRow) && (sHeaderKey[cell.getColumnIndex()] != null)) {
						sValue = Arrays.copyOf(sValue, cell.getColumnIndex() + 1);
						if(cell.getCellType() != Cell.CELL_TYPE_BLANK){
							sValue[cell.getColumnIndex()] = formatter.formatCellValue(cell);
						} else{
							sValue[cell.getColumnIndex()] = null;
						}
					}
				}
				if ((sHeaderKey.length != 0) && (sValue.length != 0)) 
				{
					RowData = new LinkedHashMap<String, String>();
					for (int i = 0; i < sHeaderKey.length; i++) 
					{
						if (i < sValue.length)
						{
							RowData.put(sHeaderKey[i], sValue[i]);
						}
						else
						{
							RowData.put(sHeaderKey[i], null);
						}
					}
					DataList.add( RowData );
				}
			}
			//workbook.close();
			oFis.close();
		} catch (Exception e) {
					//log.info("Execption at excelReadHashMap(String sExcelPath, String sSheetName) in Excel.java:\n"+e.getMessage());
			e.printStackTrace();
		}
		return DataList;
	}
	
	
	
	
		public static List<Map<String,String>> readExcelMap(String filePath,String sheetName) throws Exception
		{
			List<Map<String,String>> objList = new ArrayList<Map<String,String>>(); 
			Map<String,String> objMap = null;
			List<String> colList=new ArrayList<String>();
			List<String> rowList=null;
		    FileInputStream fis = new FileInputStream(filePath);
		    Workbook workbook = new XSSFWorkbook(fis);
		    Sheet sheet = workbook.getSheet(sheetName);
		    int lastRow = sheet.getLastRowNum();
		    for(int i=0;i<=lastRow;i++)
		    {
		    	Row row = sheet.getRow(i);
		    	int lastCol=row.getLastCellNum();
		    	
		    	if(i>0)
		    	{
		    		rowList=new ArrayList<String>();
		    		for(int j=0;j<lastCol;j++)
		    		{
		    			Cell cell=row.getCell(j);
		    			String value=cell.getStringCellValue();
		    			rowList.add(value);
		    		}
		    	}
		    	else
		    	{
		    		for(int j=0;j<lastCol;j++)
		    		{
		    			Cell cell=row.getCell(j);
		    			String value=cell.getStringCellValue();
		    			colList.add(value);
		    		}
		    	}
		    	
		    	if(i!=0 && rowList.size()==colList.size() )
		    	{
		    		objMap=new HashMap<String,String>();
		    		for(int k=0;k<rowList.size();k++)
		    		{
		    			objMap.put(colList.get(k),rowList.get(k));
		    		}
		    		objList.add(objMap);
		    	}
		    	
		    }
		    
			  
			return objList;
			
		}

}

