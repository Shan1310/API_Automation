package Evoke.utilities;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
import com.google.common.collect.ImmutableMap;
import io.qameta.allure.Allure;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;



public class TestBase {

	public static WebDriver driver;
	public static Properties prop;
	public static LinkedHashMap<String, String> data;
	public static String Emailidvalue;
	public static String Passwordvalue;
	public static String LocationfromValue;
	public static String toLocationValue;
	public static String DatetimeDepartValue;
	public static String OutwardDepartAfterValue;
	public static String TimetableonlyValue;
	public static String IsSeasonTicketValue;
	public static String ShowServicesValue;
	public static String OnewayValue;
	public static String OpenreturnValue;
	public static String MonthlyValue;
	public static String DirectServicesOnlyValue;
	public static String StandardclassValue;
	public static String FirstclassValue;
	public static String PassengergroupValue;
	public static String EnquirymethodValue;
	public static String SleepersOnlyValue;
	public static String Serviceidvalue;
	public static String Faregroupvalue;
	public static String Deliveryoptionvalue;
	public static String PurchaseFromdatevalue;
	public static String Purchasetodatevalue;
	public static String Fulfilmentmethodtypevalue;
	public static String Producttypevalue;
	public static String NewPasswordvalue;
	
	public static String sdateTimeReturn;
	public static String sreturnDepartAfter;
	public static String sReturnServiceid;
	public static String sReturnFaresGroup;
	
	public static String sReturnid;
	public static String sReturnGroup;

	public static Logger log = (Logger) LogManager.getLogger("Evoke_API__Logger"); 
	
	public static int explicitWait = 120;
	
	public static SoftAssert softassert1 = new SoftAssert();
	public static SoftAssert softassert2 = new SoftAssert();
	public static SoftAssert softassert3 = new SoftAssert();
	public static SoftAssert softassert4 = new SoftAssert();
	public static SoftAssert softassert5 = new SoftAssert();
	public static SoftAssert softassert6 = new SoftAssert();
	public static SoftAssert softassert7 = new SoftAssert();
	public static SoftAssert softassert8 = new SoftAssert();
	
	static
	{
		String toLocationValue;
		prop=new Properties();
		FileInputStream ip;
		try 
		{
			ip = new FileInputStream("src\\test\\java\\Evoke\\configuration\\Config.Properties");
			prop.load(ip);
			
			AllureEnvironment.setAllureEnvironment(
	                ImmutableMap.<String, String>builder()
	                        .put("Project", prop.getProperty("ProjectName"))
	                        .put("Environment", prop.getProperty("Environment"))
	                        .put("Platform", prop.getProperty("PlatformName"))
	                        .put("Platform Version", prop.getProperty("PlatformVersion"))
	                        .build(), System.getProperty("user.dir")
	                        + "/allure-results/"); 
		}
		catch (Exception e) 
		{
				e.printStackTrace();
		}
	}
	public static void setData(int row) {
		
		List<LinkedHashMap<String, String>> obj = ExcelReader.excelReadHashMap(prop.getProperty("testDataPath"),"Rail-POST");
		LinkedHashMap<String, String> data = (LinkedHashMap<String, String>) obj.get(row);
		Emailidvalue = data.get("Email");
		Passwordvalue = data.get("Password");
		LocationfromValue=data.get("locfrom");
		toLocationValue=data.get("locto");
		DatetimeDepartValue=data.get("datetimedepart");
		OutwardDepartAfterValue=data.get("outwardDepartAfter");
		TimetableonlyValue=data.get("timetableonly");
		IsSeasonTicketValue=data.get("isSeasonTicket");
		ShowServicesValue=data.get("showServices");
		OnewayValue=data.get("oneway");
		OpenreturnValue=data.get("openreturn");
		MonthlyValue=data.get("monthly");
		DirectServicesOnlyValue=data.get("directServicesOnly");
		StandardclassValue=data.get("standardclass");
		FirstclassValue=data.get("firstclass");
		PassengergroupValue=data.get("passengergroup");
		EnquirymethodValue=data.get("enquirymethod");
		SleepersOnlyValue=data.get("sleepersOnly");
		Serviceidvalue = data.get("Serviceid");
		Faregroupvalue = data.get("Faregroup");
		Deliveryoptionvalue = data.get("Expectecteddeloption");
		PurchaseFromdatevalue = data.get("Purchasefromdate");
		Purchasetodatevalue= data.get("PurchaseTodate");
		Fulfilmentmethodtypevalue= data.get("fulfilmentmethodtype");
		Producttypevalue= data.get("producttype");
		NewPasswordvalue = data.get("newpassword");
		
		sdateTimeReturn= data.get("dateTimeReturn");
		sreturnDepartAfter= data.get("returnDepartAfter");
		sReturnid= data.get("ReturnServiceid");
		sReturnGroup= data.get("ReturnFaresGroup");

		
	}
	public static void launchBrowser()
	{
		try
		{
			if(prop.getProperty("env").equalsIgnoreCase("browserstack"))
			{
				createInstanceOnBrowserStack();	
			}
			else if(prop.getProperty("env").equalsIgnoreCase("local"))
			{
				createInstanceOnLocalMachine();
			}
			else
			{
				//log.info("Please specify Environment browserstack or local and then try again");
				//System.exit(0);
			}
			
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void createInstanceOnLocalMachine() throws Exception 
	{	
		 	System.setProperty("webdriver.chrome.driver",prop.getProperty("chromeDriverPath"));
		   // System.setProperty("webdriver.chrome.driver","/RegressionAPI/Drivers/chromedriver.exe");
		 	String downloadFilepath = "C:\\Users\\"+System.getProperty("user.name")+"\\Downloads";
	        HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
	        chromePrefs.put("profile.default_content_settings.popups", 0);
	        chromePrefs.put("download.default_directory", downloadFilepath);
	        chromePrefs.put("safebrowsing.enabled", "true"); 
	        ChromeOptions options = new ChromeOptions();
	        options.setExperimentalOption("prefs", chromePrefs);
	        driver = new ChromeDriver(options);
	        setdriver(driver);
	 }
	    

	 public static void createInstanceOnBrowserStack() throws Exception 
	 {
	    	String USERNAME = "alistairsnow1";
	  	    String AUTOMATE_KEY = "rpRRNEkpvcMhpLNFprwm";
	  	    String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
	   
	  	    DesiredCapabilities caps = new DesiredCapabilities();
	    	   caps.setCapability("browser",prop.getProperty("browser"));
	    	   caps.setCapability("browser_version",prop.getProperty("browser_version"));
	    	   caps.setCapability("os",prop.getProperty("os"));
	    	   caps.setCapability("os_version",prop.getProperty("os_version"));
	    	   caps.setCapability("build",prop.getProperty("build"));
	    	   caps.setCapability("browserstack.debug",prop.getProperty("browserstack.debug"));
	    	   caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	    	   driver = new RemoteWebDriver(new URL(URL),caps);
	      
	        setdriver(driver);
	    }
	    
	public static void setdriver(WebDriver driver) 
	{	
		TestBase.driver=driver;
	}
	
	
	public void closeBrowser()
	{
		driver.quit();
	}
	
	public static void ScreenshotStep(String screenshotName) throws Exception {
		// String screenshotName = "Screenshot";
		Thread.sleep(2000);
		InputStream screenshot = new ByteArrayInputStream(
				((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES));
		Allure.addAttachment(screenshotName, "image/png", screenshot, "png");
	}

	public static void DisplayOutputinReport(String heading, String actual) throws Exception {

		Allure.addAttachment(heading, actual);

	}
	
	public static boolean isElementPresent(By element) {
		boolean flag = false;
		try {
			if (driver.findElement(element).isDisplayed()) {
				flag = true;
			}
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}
	
	
	public static boolean waitForElement(By locator, int interval, String modeType) {
		WebElement elm = null;
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, interval);
			switch (modeType.trim().toUpperCase()) {
			case "VISIBILIITYOFELEMENTLOCATED":
				wait.until(ExpectedConditions.visibilityOf((WebElement) locator));
				break;
			case "INVISIBILITYOFELEMENTLOCATED":
				wait.until(ExpectedConditions.invisibilityOf((WebElement) locator));
				break;
			case "ELEMENTTOBECLICKABLE":
				wait.until(ExpectedConditions.elementToBeClickable(locator));
				break;
			case "STALENESS":
				wait.until(ExpectedConditions.stalenessOf((WebElement) locator));
				break;
			}
			flag = true;
		} catch (Exception e) {
			// e.printStackTrace();
			flag = false;
		}
		return flag;
	}
	
	public static void CheckAssert() {
		softassert1.assertAll();
		softassert2.assertAll();
	}
}
