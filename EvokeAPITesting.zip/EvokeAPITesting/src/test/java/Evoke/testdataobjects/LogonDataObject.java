package Evoke.testdataobjects;

import gherkin.deps.com.google.gson.internal.LinkedTreeMap;

public class LogonDataObject {

	public String Username;
	public String Password;
	public String Staffid;
	public String UsernameValue;
	public String PasswordValue;
	public String StaffIdValue;
	public String NewPasswordValue;

	public LogonDataObject(LinkedTreeMap<String, ?> map) {
		this.Username = (String) map.get("emailId");
		this.UsernameValue = (String) map.get("emailValue");
		this.Password = (String) map.get("pwd");
		this.Staffid = (String) map.get("staffIdParam");
		this.PasswordValue = (String) map.get("passwordValue");
		// this.Staffid= (String) map.get("staffIdParam");
		this.StaffIdValue = (String) map.get("staffidValue");
		this.NewPasswordValue = (String) map.get("newpasswordvalue");

	}

	public String getUserNameField() {
		return Username;
	}

	public String getPasswordField() {
		return Password;
	}

	public String getStaffidField() {
		return Staffid;
	}

	public String getUsernameValue() {
		return UsernameValue;
	}

	public String getPasswordValue() {
		return PasswordValue;
	}

	public String getStaffIdValue() {
		return StaffIdValue;
	}

	public String getNewPasswordValue() {
		return NewPasswordValue;
	}
}
