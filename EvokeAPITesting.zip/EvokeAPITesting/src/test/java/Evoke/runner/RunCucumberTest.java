package Evoke.runner;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features ="src/test/java/Evoke/features/Latest_Evoke.feature", 
plugin = { "pretty", "html:target/cucumber-html-reports",  
"io.qameta.allure.cucumber4jvm.AllureCucumber4Jvm", 		
"rerun:target/failed_scenarios.txt" },
monochrome = true, 
glue = {"Evoke/stepdefinition"},

//tags = {"@ChangeFulfillmentInputToPassAvailablePrinterTypesforProcessTransactionandchecktheResponse,@RunProcessTransactionWithMultipleTicketwhichisaddedintoBasketforAvailablePrintersandchecktheResponse,@StartshiftToEndshiftandChecktheStatusWithRunningfailTransaction,@AddMultipleTicketsintoBasketandthenRunfailTransactionsandCheckTheStatus,@RunMultipleFullTransactionAndFailLastTransactionInOneShift,@RunStartshiftToEndshiftandChecktheStatusforSingleTravelTicket,@RunStartshiftToEndshiftandChecktheStatusforOneOutwardAndOneReturnTravelTicket,@RunFailTransactionBeforeProcessTransactionAndValidateTheErrorCode,@ToValidateErrorCodeWhenStartShiftNotStarted,@ToValidateErrorCodeWhenEndShiftAlreadyStopped,@ChecktheStatusAfterStartShiftAndEndShift,@ToValidateErrorCodeKeepingtheTisIdBlank-1001,@ToValidateErrorCodeWhenRunEndShiftAPItwice-2001,@ToValidateErrorCodeWhenRuntheStartShiftAPICallKeepingBodyOftheStartShiftAPIEmpty-2005,@ToValidateStartShiftWithMoreThanEightCharectorofUserIdandVerifyErrorCode-2006,@ToValidateStartShiftWithInvalidAlphanumericUserIdandVerifyErrorCode-2007,@ToValidateRunEndShiftandthenRunProcessTransactionAPIWithoutStartShiftandVerifyErrorCode-3000,@ToValidateRunTransactionAPICallWithInvalidBasketAndVerifyErrorCode-3005,@RunTheProcessTransactionCallWhenPaymentTotalDoesn'tMatchBasketTotal-3016,@PaymentContainsInvalidReference-3018,@PaymentContainInvalidMaskedPAN-3019,@RunTheFailProcessTransactionCallWithoutStartShift-4002,@RunTheFailProcessTransactionCallWhenNoTransactionFound-4005,@RunTheProcessTransactionforPastTrip-3017,@RunTheProcessTransactionCallWithoutPaymentDetails-3015,@SelectAFareWhichhasMandatoryReservationAndRunProcessTransactionAPI-3014,@FailPreviousProcessTransactionTwiceErrorCode-4004,@ToValidateConfigurationAPI,@ToRemovetheAssetDetailsandChecktheChanges,@SeparateouttheconfigurationAPI"})
//tags = {"@ChangeFulfillmentInputToPassAvailablePrinterTypesforProcessTransactionandchecktheResponse"})
//tags = {"@RunStartshiftToEndshiftandChecktheStatusforSingleTravelTicket"})
tags = {"@ChangeFulfillmentInputToPassAvailablePrinterTypesforProcessTransactionandchecktheResponse"})
//tags = {"@ToValidateConfigurationAPI,@ToRemovetheAssetDetailsandChecktheChanges"})
 // tags= {"@SeparateouttheconfigurationAPI"})
//tags = {"@SelectAfareWhichCannotbeFulfilledByE-ticketandRunProcessTransactionAPIandVerifyErrorCode-3011"})

//tags = {"@Test_1,@Test_2,@Test_3,@Test_4,@Test_5,@Test_6,@Test_7,@Test_8,@Test_9,@Test_10,@Test_11,@Test_12"})

//@ToValidateConfigurationAPI
//@ToRemovetheAssetDetailsandChecktheChanges
//@RunTheProcessTransactionforPastTrip-3017
//@RunTheProcessTransactionCallWithoutPaymentDetails-3015
//@SelectAFareWhichhasMandatoryReservationAndRunProcessTransactionAPI-3014

public class RunCucumberTest extends AbstractTestNGCucumberTests
{
	
}
